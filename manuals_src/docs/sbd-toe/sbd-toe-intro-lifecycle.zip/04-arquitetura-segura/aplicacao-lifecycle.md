---
id: aplicacao-lifecycle
title: Ciclo de Vida de Aplicação — Arquitetura Segura
description: Como aplicar os requisitos e práticas de arquitetura segura ao longo do ciclo de vida de software
tags: [ciclo de vida, arquitetura, requisitos, rastreabilidade]
sidebar_position: 15
---

# 📅 Aplicação no Ciclo de Vida — Arquitetura Segura {arquitetura-segura:canon:aplicacao-lifecycle}

Este documento descreve **como aplicar, validar e manter as práticas de arquitetura segura** (`ARC-001` a `ARC-011`) ao longo do ciclo de desenvolvimento, desde o design inicial até à manutenção evolutiva.

> O objetivo é garantir que a arquitetura segura atua como **mecanismo estruturado, rastreável e iterativo**, com impacto técnico e processual contínuo.

---

## ♻️ Fases de Aplicação {arquitetura-segura:canon:aplicacao-lifecycle#fases_de_aplicacao}

| Fase / Momento                     | Ação esperada                                                     | Requisitos envolvidos           |
|-----------------------------------|-------------------------------------------------------------------|---------------------------------|
| ⭐ Início do projeto               | Selecionar modelo arquitetural e definir zonas de confiança       | ARC-001 a ARC-004, ARC-007      |
| 🖊️ Design inicial                 | Produzir diagrama com fronteiras técnicas e fluxos identificados  | ARC-001, ARC-002, ARC-003       |
| 📊 Revisão técnica informal        | Aplicar checklist de validação proporcional ao risco              | ARC-005, ARC-006                |
| ✅ Aprovação formal de arquitetura | Avaliação AppSec + threat modeling estruturado                    | ARC-005, ARC-010                |
| ⚖️ Justificação de exceção         | Submeter formulário formal com plano de mitigação                 | ARC-011                         |
| ♻️ Alteração estrutural           | Rever o diagrama e atualizar rastreabilidade                      | Todos                           |
| 🚀 Go Live / Release              | Arquivar artefactos: diagramas, exceções, validações              | ARC-004, ARC-008, ARC-011       |
| 🔁 Reavaliação periódica           | Rever arquitetura em grandes releases ou alterações de contexto   | ARC-005, ARC-006, ARC-008       |

---

## 📃 Artefactos Recomendados por Projeto {arquitetura-segura:canon:aplicacao-lifecycle#artefactos_recomendados_por_projeto}

| Tipo de Artefacto                   | Obrigatório | Fase Associada           | Observações                                          |
|------------------------------------|-------------|---------------------------|------------------------------------------------------|
| Diagrama de arquitetura versionado | Sim         | Design + validação        | `.drawio`, `.puml`, `.svg`, sob controlo de versão   |
| Checklist de validação             | Sim         | Revisão + aprovação        | Ver `addon/04-validacao-modelo-arquitetura.md`       |
| Formulário de exceção              | Condicional | Se ARC-011 for invocado   | Ver `addon/05-excecoes-arquitetura.md`               |
| Mapeamento requisitos → componentes| Sim         | Design + manutenção       | Ver `addon/02-mapeamento-controles-arquitetura.md`   |
| Registo de threat modeling         | L2/L3       | Design + revisão técnica  | Template STRIDE ou equivalente                      |

---

## 🔄 Integração com o Ciclo de Vida {arquitetura-segura:canon:aplicacao-lifecycle#integracao_com_o_ciclo_de_vida}

As práticas de arquitetura segura devem ser integradas em:

- Pull requests com impacto estrutural
- RFCs ou ADRs com alterações arquiteturais
- Pipelines CI/CD: validação de diagrama, rastreabilidade e bloqueio por exceções
- Planeamento de releases e alterações em zonas de confiança
- Auditorias internas e gates de go/no-go técnicos

---

## 🔧 Pontos de Controlo Auditáveis {arquitetura-segura:canon:aplicacao-lifecycle#pontos_de_controlo_auditaveis}

- Validação arquitetural proporcional ao risco da aplicação
- Existência de zonas de confiança e fronteiras técnicas explícitas
- Rastreabilidade entre requisitos, arquitetura e componentes
- Justificação formal de exceções com plano de mitigação
- Diagrama versionado e artefactos arquivados por release

---

## 🧾 User Stories e Cartões Reutilizáveis {arquitetura-segura:canon:aplicacao-lifecycle#user_stories_e_cartoes_reutilizaveis}

Estes exemplos suportam a operacionalização prática de cada requisito `ARC-00x`. Devem ser utilizados em boards técnicos, pipelines e revisões formais.

---

### 🟦 ARC-001 — Delimitação de Zonas de Confiança {arquitetura-segura:canon:aplicacao-lifecycle#arc_001__delimitacao_de_zonas_de_confianca}

> Como arquiteto, quero definir zonas de confiança explícitas para os diferentes componentes da aplicação, para garantir isolamento lógico e modelar corretamente os fluxos.

**Checklist:**
- [ ] Identificação de zonas (ex: frontend, backend, admin)
- [ ] Justificação da separação
- [ ] Refletido no diagrama de arquitetura

---

### 🟨 ARC-002 — Definição de Fronteiras Técnicas {arquitetura-segura:canon:aplicacao-lifecycle#arc_002__definicao_de_fronteiras_tecnicas}

> Como analista de segurança, quero validar que existem fronteiras técnicas entre zonas de confiança, para prevenir acesso lateral indevido.

**Checklist:**
- [ ] Firewalls, gateways, proxies ou segmentações declaradas
- [ ] Validação de mecanismos de controlo
- [ ] Logging em pontos de fronteira

---

### 🟩 ARC-003 — Identificação de Fluxos {arquitetura-segura:canon:aplicacao-lifecycle#arc_003__identificacao_de_fluxos}

> Como engenheiro de software, quero garantir que todos os fluxos interzonais estão mapeados, autenticados e validados, para evitar exposição indevida.

**Checklist:**
- [ ] Fluxos documentados entre zonas
- [ ] Autenticação de serviço a serviço
- [ ] Validação de dados à entrada e saída

---

### 🟫 ARC-004 — Documentação de Decisões Arquiteturais {arquitetura-segura:canon:aplicacao-lifecycle#arc_004__documentacao_de_decisoes_arquiteturais}

> Como equipa técnica, queremos manter um registo das decisões arquiteturais, para garantir rastreabilidade e contexto técnico a longo prazo.

**Checklist:**
- [ ] ADRs ou RFCs versionados
- [ ] Justificativa técnica e de risco
- [ ] Ligação a requisitos ARC

---

### 🟥 ARC-005 — Validação Proporcional ao Risco {arquitetura-segura:canon:aplicacao-lifecycle#arc_005__validacao_proporcional_ao_risco}

> Como revisor técnico, quero aplicar uma validação arquitetural proporcional ao nível de risco da aplicação, para garantir que os controlos estão alinhados com a criticidade.

**Checklist:**
- [ ] Checklist preenchido
- [ ] Participação de segurança (AppSec)
- [ ] Ligação a classificações L1–L3

---

### 🟪 ARC-006 — Rastreabilidade Técnica {arquitetura-segura:canon:aplicacao-lifecycle#arc_006__rastreabilidade_tecnica}

> Como arquiteto, quero manter a rastreabilidade entre requisitos, componentes e validações, para garantir consistência, auditoria e manutenção segura.

**Checklist:**
- [ ] Tabela requisitos → componentes atualizada
- [ ] Ligação entre código/infra e artefactos
- [ ] Atualização após alterações estruturais

---

### 🟧 ARC-007 — Validação de Padrões Reutilizados {arquitetura-segura:canon:aplicacao-lifecycle#arc_007__validacao_de_padroes_reutilizados}

> Como arquiteto, quero garantir que os padrões arquiteturais reutilizados estão atualizados, seguros e aprovados, para evitar anti-padrões e riscos herdados.

**Checklist:**
- [ ] Modelo base identificado
- [ ] Conformidade validada com ARC
- [ ] Atualizações registadas e comunicadas

---

### 🟨 ARC-008 — Arquivamento de Artefactos {arquitetura-segura:canon:aplicacao-lifecycle#arc_008__arquivamento_de_artefactos}

> Como equipa DevOps, queremos garantir que os artefactos arquiteturais estão arquivados com cada release, para assegurar rastreabilidade e referência futura.

**Checklist:**
- [ ] Diagrama versionado
- [ ] Checklist validado e anexado
- [ ] Exceções documentadas (se existirem)

---

### 🟦 ARC-009 — Aderência a Modelos de Referência {arquitetura-segura:canon:aplicacao-lifecycle#arc_009__aderencia_a_modelos_de_referencia}

> Como equipa técnica, queremos garantir que a arquitetura adere a um modelo de referência aceite, para promover consistência, reuso e aceleração de decisões.

**Checklist:**
- [ ] Modelo de referência explícito
- [ ] Validação de diferenças
- [ ] Aprovação técnica formalizada

---

### 🟧 ARC-010 — Integração com Threat Modeling {arquitetura-segura:canon:aplicacao-lifecycle#arc_010__integracao_com_threat_modeling}

> Como equipa de segurança, queremos que a arquitetura sirva de base para threat modeling estruturado, para identificar ameaças e planear controlos.

**Checklist:**
- [ ] DFD ou STRIDE sobre o diagrama
- [ ] Cobertura de zonas, fluxos e trust boundaries
- [ ] Ações mitigadoras registadas

---

### 🟥 ARC-011 — Gestão Formal de Exceções {arquitetura-segura:canon:aplicacao-lifecycle#arc_011__gestao_formal_de_excecoes}

> Como PO ou owner técnico, quero que todas as exceções aos requisitos arquiteturais estejam justificadas e tenham plano de mitigação, para reduzir risco residual.

**Checklist:**
- [ ] Exceção aprovada com validade
- [ ] Plano compensatório definido
- [ ] Reavaliação agendada

---

> 🔁 Estes cartões podem ser usados como base para automatizações, critérios de aceite e artefactos de auditoria formal.
