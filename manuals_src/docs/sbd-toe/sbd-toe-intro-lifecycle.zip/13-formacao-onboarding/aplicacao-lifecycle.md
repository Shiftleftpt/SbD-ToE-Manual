---
id: aplicacao-lifecycle
title: Aplicação de Formação e Onboarding ao Longo do Ciclo de Vida
description: Integração prática e validável das práticas de formação, onboarding e capacitação de terceiros ao longo do ciclo de vida.
tags: [formacao, onboarding, ciclo de vida, champions, terceiros, risco]
sidebar_position: 15
---


# 🎓 Aplicação de Formação e Onboarding ao Longo do Ciclo de Vida {formacao-onboarding:canon:aplicacao-lifecycle}

Este documento demonstra **como aplicar as práticas prescritas no Capítulo 13 — Formação e Onboarding Seguro ao longo do ciclo de vida de desenvolvimento**, desde a entrada de novos colaboradores até à capacitação contínua de equipas internas e externas.

Inclui **ações concretas por fase**, artefactos reutilizáveis, user stories com checklists e aplicação proporcional ao nível de risco da aplicação (L1–L3).

---

## 🧭 Quando aplicar práticas de formação e onboarding {formacao-onboarding:canon:aplicacao-lifecycle#quando_aplicar_praticas_de_formacao_e_onboarding}

| Fase / Evento                          | Ação esperada                                                                                  | Artefacto principal                           |
|---------------------------------------|-----------------------------------------------------------------------------------------------|-----------------------------------------------|
| Entrada de colaborador técnico        | Atribuição de trilho formativo + checklist de onboarding                                      | `checklist-onboarding.md`                     |
| Classificação de risco da aplicação   | Definição do nível L1–L2–L3 que regula os requisitos mínimos de formação                      | Avaliação de risco + mapeamento por função    |
| Formação inicial                      | Conclusão do trilho correspondente ao perfil e risco                                          | `trilho-formativo.md`, `manual-formacao.md`   |
| Validação                             | Realização de quiz e/ou revisão prática (ex: PR simulada) com limiar mínimo definido          | `quiz-onboarding.md`, registos LMS ou Git     |
| Inclusão de fornecedores ou terceiros | Formação mínima, termo de responsabilidade, validação e registo formal                        | `formacao-terceiros.md`, cláusula contratual  |
| Onboarding de equipas externas        | Sessão síncrona, SPOC interno, registo de aceitação de práticas                               | `plano-formacao-terceiros.md`, `indicadores.md` |
| Reforço contínuo                      | PR Clinics, war rooms, partilha de PRs exemplares, sessões temáticas                          | Calendário, repositório `pr-exemplos/`        |
| Mudança tecnológica / incidente       | Atualização de conteúdos formativos, envio para perfis relevantes e registo de comunicação     | `manual-formacao-por-capitulo.md`             |

---

## 👥 Quem executa cada ação {formacao-onboarding:canon:aplicacao-lifecycle#quem_executa_cada_acao}

| Papel / Função         | Responsabilidades                                                                 |
|------------------------|------------------------------------------------------------------------------------|
| AppSec / Segurança     | Curadoria dos conteúdos, definição de trilhos, validação de quizzes e métricas     |
| RH / IT / People Ops   | Integração de formação no processo de entrada, registo de onboarding e permissões  |
| Tech Leads / DevOps    | Validação informal de PRs, reforço nos rituais técnicos, apoio no onboarding       |
| Champions              | Apoio próximo, organização de sessões, disseminação prática do conteúdo            |
| Terceiros e fornecedores| Sujeitos aos mesmos requisitos, com rastreabilidade e registos auditáveis         |
| Gestão / PMO           | Visibilidade institucional, KPIs e responsabilidade contratual sobre capacitação   |

---

## 🧾 User Stories e Cartões Reutilizáveis {formacao-onboarding:canon:aplicacao-lifecycle#user_stories_e_cartoes_reutilizaveis}

### 🟦 Story: Atribuição de trilho formativo por risco e função {formacao-onboarding:canon:aplicacao-lifecycle#story_atribuicao_de_trilho_formativo_por_risco_e_funcao}

> Como AppSec, quero garantir que cada novo colaborador recebe um trilho de formação proporcional ao risco e ajustado ao seu papel, para garantir alinhamento mínimo com as práticas de segurança.

**Checklist:**

- [ ] Classificação de risco da aplicação (L1–L3) determinada
- [ ] Perfil técnico identificado (Dev, QA, DevOps, etc.)
- [ ] Trilho formativo atribuído e registado
- [ ] Prazo de conclusão definido e comunicado

---

### 🟦 Story: Validação de onboarding antes de permissões técnicas {formacao-onboarding:canon:aplicacao-lifecycle#story_validacao_de_onboarding_antes_de_permissoes_tecnicas}

> Como Tech Lead, quero garantir que ninguém recebe permissões técnicas sem validação da formação, para reduzir o risco de erro humano ou má configuração.

**Checklist:**

- [ ] Quiz realizado e aprovado com ≥ 80%
- [ ] PR real ou simulado revisto com foco em segurança
- [ ] Checklist de onboarding completo e arquivado
- [ ] Permissões atribuídas apenas após validação

---

### 🟦 Story: Inclusão segura de terceiros e fornecedores {formacao-onboarding:canon:aplicacao-lifecycle#story_inclusao_segura_de_terceiros_e_fornecedores}

> Como PMO, quero garantir que fornecedores externos passam por um processo formal de formação e validação antes de acesso técnico, para mitigar riscos de terceiros.

**Checklist:**

- [ ] Termo de responsabilidade assinado
- [ ] Formação mínima realizada e comprovada
- [ ] Validação documentada (quiz, PR)
- [ ] Registo arquivado com nome, empresa, datas e resultado

---

### 🟦 Story: Reforço contínuo e PR Clinics {formacao-onboarding:canon:aplicacao-lifecycle#story_reforco_continuo_e_pr_clinics}

> Como Champion, quero organizar sessões de PR Clinic e partilha de boas práticas, para reforçar continuamente o conhecimento da equipa.

**Checklist:**

- [ ] Sessões agendadas e comunicadas
- [ ] Casos reais selecionados e analisados
- [ ] Participação registada por perfil
- [ ] Follow-up documentado e partilhado

---

### 🟦 Story: Atualização de conteúdos após incidente ou mudança {formacao-onboarding:canon:aplicacao-lifecycle#story_atualizacao_de_conteudos_apos_incidente_ou_mudanca}

> Como AppSec, quero atualizar os conteúdos de formação após incidentes ou alterações tecnológicas, para manter os materiais relevantes e eficazes.

**Checklist:**

- [ ] Incidente analisado com causas identificadas
- [ ] Conteúdos atualizados nos materiais aplicáveis
- [ ] Reforço enviado aos perfis impactados
- [ ] Comunicação e rastreabilidade asseguradas

---

### 🟦 Story: Onboarding leve para contractor individual {formacao-onboarding:canon:aplicacao-lifecycle#story_onboarding_leve_para_contractor_individual}

> Como Champion, quero garantir que contractors recebam formação mínima e validação antes do acesso, mesmo que o onboarding seja abreviado.

**Checklist:**

- [ ] Trilho reduzido atribuído
- [ ] Quiz básico completado
- [ ] PR simulado revisto ou explicação supervisionada
- [ ] Confirmação de acesso condicionado à formação

---

### 🟦 Story: Formação padronizada por capítulo do manual {formacao-onboarding:canon:aplicacao-lifecycle#story_formacao_padronizada_por_capitulo_do_manual}

> Como AppSec, quero garantir que todos os capítulos do SbD-ToE incluem formação associada, para reforçar a aplicação prática das práticas de segurança.

**Checklist:**

- [ ] Material específico do capítulo revisto (addon/06)
- [ ] Manual de formação atualizado
- [ ] Disseminação feita por Champion ou repositório interno
- [ ] Registo de uso (formação, quiz ou PR) arquivado

---

## 📄 Templates e Artefactos Esperados {formacao-onboarding:canon:aplicacao-lifecycle#templates_e_artefactos_esperados}

| Artefacto                        | Formato Recomendado             | Onde Guardar ou Referenciar                   |
|----------------------------------|----------------------------------|-----------------------------------------------|
| Checklist de onboarding          | Markdown / Formulário            | Git, LMS ou SharePoint                        |
| Quiz de validação                | Google Form, LMS, Markdown       | Plataforma de formação ou PR                  |
| Trilho formativo por função      | YAML / Markdown                  | `addon/02-trilho-formativo.md`                |
| Termo de responsabilidade        | PDF assinado / digital           | RH, ITSM ou registo contratual                |
| Repositório de exemplos de PRs   | GitHub/GitLab com tagging        | Diretório `pr-exemplos/`                      |
| Manual de formação por capítulo  | Markdown estruturado             | `addon/06-manual-formacao-por-capitulo.md`    |
| Indicadores e métricas           | CSV / Dashboard / YAML           | `addon/90-indicadores-metricas.md`            |

---

## ⚖️ Aplicação Proporcional por Nível de Risco (L1–L3) {formacao-onboarding:canon:aplicacao-lifecycle#aplicacao_proporcional_por_nivel_de_risco_l1l3}

| Prática                           | L1 (baixo risco)         | L2 (risco moderado)             | L3 (risco elevado)                       |
|----------------------------------|--------------------------|----------------------------------|------------------------------------------|
| Formação mínima                  | Vídeo ou awareness       | Trilho curto + quiz              | Trilho completo + PR revisto             |
| Validação antes de permissões   | Opcional                 | Quiz informal                    | Obrigatória com registo formal           |
| Formação de terceiros            | Condicional              | Formação básica + termo assinado | Formação completa + rastreio por contrato|
| Reforço contínuo                 | Semestral                | Trimestral com métricas          | Mensal com war rooms e clinics           |
| Rastreabilidade de onboarding    | Manual ou informal       | Documentado em repositório       | Automatizado com KPIs e alertas          |

---

## ✅ Recomendações Finais {formacao-onboarding:canon:aplicacao-lifecycle#recomendacoes_finais}

- A formação deve ser **proporcional ao risco, mas obrigatória antes de permissões técnicas**.
- **Terceiros, contractors e fornecedores** devem seguir o mesmo processo com adaptações contratuais.
- O programa de **Champions** deve ser usado como motor de reforço prático, com sessões regulares e exemplos reais.
- As **exceções ao processo devem ser formalmente aprovadas** e documentadas.
- Os artefactos formativos devem ser **versionados, acessíveis e auditáveis**.

> 📌 Estas práticas permitem garantir **segurança baseada em capacitação prática e validável**, alinhada com os princípios fundamentais do modelo SbD-ToE.
