---
id: intro
title: CI/CD Seguro
description: Práticas de segurança para pipelines de integração e entrega contínua, com foco em automação, rastreabilidade e controle por risco
tags: [cicd, segurança, pipelines, automação, proveniência, devsecops, risco]
---
import Badge from '@site/src/components/Badge';

<div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1rem' }}>
  <Badge color="warning">Capítulo Basilar</Badge>
  <Badge color="info">SAMM: 2 / 3</Badge>
  <Badge color="info">BSIMM: CMVM1.3, SE2.5, CP1.2</Badge>
  <Badge color="info">SSDF: PW.4–7, PS.3, RV.3, GV.2–3</Badge>
  <Badge color="info">SLSA: Nível 3 / 4</Badge>
  <Badge color="info">DSOMM: 3 / 4 (média)</Badge>
  <a href="./canon/10-maturidade.md" style={{ marginLeft: 'auto', fontSize: '0.9rem' }}>📄 Ver análise de maturidade</a>
</div>


# CI/CD Seguro {cicd-seguro:intro}

## 🧠 Enquadramento e Rationale {cicd-seguro:intro#enquadramento_e_rationale}

Os pipelines CI/CD são hoje um dos principais alvos de ataque nas cadeias de desenvolvimento, pois controlam a **produção, modificação e entrega de código e artefactos**. Um pipeline comprometido compromete **todas as aplicações** que por ele passam.

Este capítulo aborda as práticas essenciais para proteger pipelines CI/CD, agentes de execução, credenciais, artefactos e os próprios scripts de automação — promovendo **confiança, rastreabilidade e resistência a ataques na cadeia de software**.

> ⚠️ Este domínio é crítico em ambientes DevOps. A segurança do pipeline não é apenas operacional — **é segurança de produto**.

---

## 🧭 1. O que cobre tecnicamente {cicd-seguro:intro#1_o_que_cobre_tecnicamente}

Este capítulo foca-se na segurança de:

- Pipelines de **integração contínua (CI)** e **entrega contínua (CD)**
- Ambientes de execução (runners, agentes, containers)
- Scripts de automação (YAML, Bash, PowerShell, etc.)
- Gestão de segredos e credenciais usados em pipelines
- Proveniência e integridade dos artefactos gerados
- Controlo de segurança nos ambientes de build, teste e release

---

## 🧪 2. Prescrição prática: o quê, quem, como, quando, para quê {cicd-seguro:intro#2_prescricao_pratica_o_que_quem_como_quando_para_que}

### 📌 O que deve ser feito {cicd-seguro:intro#o_que_deve_ser_feito}

1. Isolar e proteger os ambientes de execução dos pipelines
2. Usar validações de integridade e proveniência para artefactos
3. Proteger e auditar o uso de segredos nos pipelines
4. Validar todas as alterações a scripts e templates de pipeline
5. Implementar scanners automáticos nas fases adequadas
6. Garantir que os pipelines impõem controlos mínimos por risco

### ⚙️ Como deve ser feito {cicd-seguro:intro#como_deve_ser_feito}

- Separar ambientes e runners por projeto ou risco
- Usar ferramentas como `semgrep`, `trivy`, `cosign`, `scorecard`
- Assinar artefactos e definir gates por política organizacional
- Armazenar logs, releases e metadados com proveniência estruturada (ex: SLSA)

### 📆 Quando aplicar {cicd-seguro:intro#quando_aplicar}

- Em qualquer novo projeto com pipeline CI/CD
- Sempre que se promovem artefactos para produção
- Quando são atualizadas dependências, tooling ou configurações
- Ao integrar ferramentas de segurança ou gestão de segredos

### 👥 Quem está envolvido {cicd-seguro:intro#quem_esta_envolvido}

| Papel/Função        | Contributo principal                                           |
|---------------------|----------------------------------------------------------------|
| Dev Team            | Criar e manter pipelines; reagir a findings                    |
| DevOps              | Implementar segurança operacional dos pipelines e runners     |
| AppSec              | Definir políticas, critérios e validar práticas                |
| GRC / Auditoria     | Verificar rastreabilidade e conformidade organizacional        |

### 🎯 Para quê {cicd-seguro:intro#para_que}

- Prevenir ataques à cadeia de fornecimento (supply chain)
- Proteger artefactos e ambientes críticos
- Demonstrar maturidade e conformidade
- Suportar releases rápidas, seguras e auditáveis

---

## 📦 Estrutura do Capítulo {cicd-seguro:intro#estrutura_do_capitulo}

Este capítulo inclui:

- Ficheiros técnicos `01` a `09` sobre ambientes, execução, release e validação
- Addons operacionais `10-maturidade.md`, `15-aplicacao-lifecycle.md`, `20-checklist-revisao.md`
- Anexos complementares:
  - [`30-recomendacoes-avancadas.md`](xref:sbd-toe:toe:01-classificacao-aplicacoes:recomendacoes-avancadas): práticas reforçadas para pipelines críticos
  - [`50-ameacas-mitigadas.md`](xref:sbd-toe:toe:01-classificacao-aplicacoes:ameacas-mitigadas): mapeamento STRIDE, MITRE, SLSA
  - [`60-cicd-policy-template.md`](./60-cicd-policy-template.md) <!-- Precisa revisão manual -->: política organizacional formal

---

## ✅ Estado {cicd-seguro:intro#estado}

Este capítulo está **completo e validado**, com todos os elementos técnicos, operacionais e estratégicos definidos.

