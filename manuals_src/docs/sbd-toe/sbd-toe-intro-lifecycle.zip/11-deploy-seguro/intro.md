---
id: intro
title: Deploy Seguro — Introdução
description: Descrição das práticas fundamentais para garantir uma entrega segura, reversível e rastreável de código em produção.
tags: [introducao, seguranca, deploy, runtime]
sidebar_position: 0
---
import Badge from '@site/src/components/Badge';

<div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1rem' }}>
  <Badge color="warning">Capítulo Basilar</Badge>
  <Badge color="info">SAMM: 3 / 3</Badge>
  <Badge color="info">BSIMM: SE2.5, CMVM1.5, CMVM2.4</Badge>
  <Badge color="info">SSDF: RV.1.2, RV.2.3, RV.3.3</Badge>
  <Badge color="info">SLSA: Nível 2 / 4</Badge>
  <Badge color="info">DSOMM: 4 / 5 (Deploy)</Badge>
  <a href="./canon/10-maturidade.md" style={{ marginLeft: 'auto', fontSize: '0.9rem' }}>📄 Ver análise de maturidade</a>
</div>

# Deploy e Controlo de Execução {deploy-seguro:intro}

## 🧠 Enquadramento e Rationale {deploy-seguro:intro#enquadramento_e_rationale}

Uma aplicação segura não termina no build — exige práticas rigorosas de **entrega controlada**, **validação antes da ativação** e **controlo da execução em runtime**. Erros de configuração, toggles ativados inadvertidamente ou ausência de rollback podem comprometer toda a segurança aplicada nas fases anteriores.

Este capítulo estabelece práticas para garantir que o **código validado é entregue, ativado e executado com segurança**, com mecanismos de reversibilidade, limitação e monitorização pós-deploy.

> As práticas aqui descritas permitem alcançar **maturidade operacional elevada** em frameworks como **OWASP SAMM, BSIMM, SSDF, SLSA e DSOMM**, com avaliação realizada de acordo com o sistema nativo de cada modelo.

---

## 1. 🧭 O que cobre tecnicamente {deploy-seguro:intro#1__o_que_cobre_tecnicamente}

Este capítulo foca-se na segurança dos seguintes domínios:

- **Processo de release e validação formal pré-deploy**
- **Deploy progressivo e controlado (blue/green, canário, etc.)**
- **Uso seguro e rastreável de Feature Flags e toggles**
- **Controlo de execução e reversibilidade (rollback, kill switch, etc.)**
- **Separação de ambientes e autorização de deploy**
- **Gates automáticos de readiness antes da promoção**
- **Monitorização pós-deploy com triggers de rollback**

> ⚠️ A observabilidade ativa e contínua do runtime, necessária para triggers automáticos de rollback, está detalhada no **Capítulo 12 — Monitorização e Resposta**.

---

## 2. 🧪 Prescrição prática: o quê, quem, como, quando, porquê e para quê {deploy-seguro:intro#2__prescricao_pratica_o_que_quem_como_quando_porque_e_para_que}

### 📌 O que deve ser feito {deploy-seguro:intro#o_que_deve_ser_feito}

1. Definir processo de deploy controlado com **validações formais e automáticas**
2. Separar claramente os ambientes e as permissões de deploy
3. Usar feature flags com escopo definido, expiração e rastreabilidade
4. Implementar mecanismos de **rollback manual e automático**
5. Monitorizar runtime com métricas ligadas a triggers de rollback
6. Estabelecer **readiness gates** para bloquear deploys incompletos
7. Registar artefactos, owners, toggles e validações associadas à release

### ⚙️ Como deve ser feito {deploy-seguro:intro#como_deve_ser_feito}

- Integrar aprovações manuais e automáticas com base em critérios de readiness
- Usar *progressive delivery* para reduzir impacto e risco em produção
- Automatizar rollback por falha de métrica, timeout ou erro de validação
- Rastrear todos os elementos de execução: toggles, SBOM, logs, owners
- Auditar releases com base em artefactos versionados e evidência de validação

### 📆 Quando aplicar {deploy-seguro:intro#quando_aplicar}

- Em todos os **deploys para ambientes sensíveis** (QA, staging, produção)
- Ao ativar **funcionalidades via toggle** ou mecanismos runtime
- Antes de qualquer **release pública ou major**
- Sempre que houver **mudança relevante de contexto de execução**

### 👥 Quem está envolvido e como {deploy-seguro:intro#quem_esta_envolvido_e_como}

| Papel             | Responsabilidade principal                                      |
|-------------------|-----------------------------------------------------------------|
| Dev               | Integração com toggles, readiness e documentação de deploy      |
| QA / AppSec       | Validação pré-release, critérios de ativação e findings         |
| DevOps / SRE      | Execução de deploy, rollback, logging e automação de gates      |
| Gestão / Produto  | Aprovação de releases e escopo de ativação funcional            |

📋 Todas as ações ligadas ao deploy (gates, aprovação, rollback, toggle) devem ser **rastreáveis, versionadas e passíveis de auditoria**, em alinhamento com os requisitos de governação (ex: **BSIMM SE2.5**, **DSOMM Deployment Security**).

> 🎯 Todos os passos devem ser **versionados, auditáveis e documentados** para garantir rastreabilidade técnica e funcional.

---

## ⚠️ 3. Caveats e armadilhas frequentes {deploy-seguro:intro#3_caveats_e_armadilhas_frequentes}

- Feature flags sem expiração → dívida técnica de runtime
- Releases sem rollback definido → risco de indisponibilidade prolongada
- Toggles ativados sem autorização → exposição acidental
- Falta de monitorização → erros não detetados a tempo
- Readiness gates ausentes ou desativados → promoção sem critérios mínimos

---

## 💡 4. Exemplos de aplicação {deploy-seguro:intro#4_exemplos_de_aplicacao}

- Uso de toggles com escopo por utilizador e tempo limitado (ex: 14 dias)
- Releases canário com rollback automático em caso de erro
- Kill switch acionável por incident response
- Validação de readiness via pipeline com aprovação formal bloqueante
- Registo de SBOM, owners, toggles e validações por release

---

## 🔎 5. O que pode ser feito mais (níveis avançados) {deploy-seguro:intro#5_o_que_pode_ser_feito_mais_niveis_avancados}

> As práticas avançadas são descritas no ficheiro [30-recomendacoes-avancadas.md](xref:sbd-toe:toe:01-classificacao-aplicacoes:recomendacoes-avancadas), incluindo integração com RASP, gestão de toggles como código e observabilidade comportamental.

---
