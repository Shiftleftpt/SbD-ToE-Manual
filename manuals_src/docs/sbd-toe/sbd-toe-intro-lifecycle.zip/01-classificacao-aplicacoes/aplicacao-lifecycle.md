---
id: aplicacao-lifecycle
title: Aplicação da Classificação no Ciclo de Vida
sidebar_position: 15
tags: [canon, aplicacao, ciclo-vida, user-story, backlog]
---

<!--template: sbdtoe-aplicacao -->

# 🛠️ Aplicação da Classificação de Criticidade ao Longo do Ciclo de Vida {classificacao-aplicacoes:aplicacao-lifecycle}

A correta aplicação da classificação de criticidade (L1–L3) ao longo de todo o ciclo de desenvolvimento é essencial para garantir que os controlos de segurança são sempre proporcionais ao risco real, efetivamente rastreáveis e revistos de acordo com os eventos e alterações relevantes.

Este capítulo detalha, de forma operacional e prescritiva, **quando e como implementar a classificação de criticidade na prática**, descrevendo as ações esperadas por cada papel, os artefactos produzidos, e apresentando exemplos de user stories e cartões reutilizáveis — sempre de acordo com o nível de risco da aplicação.

As práticas aqui descritas estão plenamente alinhadas com frameworks de maturidade como **OWASP SAMM**, **OWASP DSOMM**, **NIST SSDF** e **ISO 27001**, assegurando que a gestão do risco deixa de ser um exercício isolado para passar a ser um controlo contínuo, auditável e verdadeiramente integrado em todo o ciclo de vida da aplicação.

---

## 🧭 Quando aplicar a classificação de criticidade {classificacao-aplicacoes:aplicacao-lifecycle#quando_aplicar_a_classificacao_de_criticidade}

| Fase / Evento                      | Ação esperada                                                  | Documento de apoio                                                        |
| ---------------------------------- |----------------------------------------------------------------|--------------------------------------------------------------------------|
| 🚧 Início de projeto               | Classificar aplicação segundo modelo E+D+I                     | [Modelo de Classificação](xref:sbd-toe:toe:01-classificacao-aplicacoes:modelo-classificacao-eixos)      |
| 🔄 Nova release ou integração      | Rever classificação com base em alterações relevantes          | [Ciclo de Vida do Risco](xref:sbd-toe:toe:01-classificacao-aplicacoes:ciclo-vida-risco)                  |
| 🛠️ Mudança nos dados ou exposição  | Reclassificar eixo D ou E, avaliar risco residual              | [Risco Residual](xref:sbd-toe:toe:01-classificacao-aplicacoes:risco-residual)                            |
| 🧪 Revisão de arquitetura          | Aplicar avaliação semiquantitativa e validar controlo aplicado| [Avaliação Semiquantitativa](xref:sbd-toe:toe:01-classificacao-aplicacoes:avaliacao-semiquantitativa)    |
| 🚀 Go-live                         | Validar conformidade com matriz de controlos por risco         | [Matriz de Controlos por Risco](xref:sbd-toe:toe:01-classificacao-aplicacoes:matriz-controlos-por-risco) |
| ⚠️ Ameaça emergente ou nova CVE    | Reavaliar criticidade e cobertura de ameaças                   | [Mapeamento de Ameaças](xref:sbd-toe:toe:01-classificacao-aplicacoes:mapeamento-ameacas-risco)           |

---

## 👥 Quem executa cada ação {classificacao-aplicacoes:aplicacao-lifecycle#quem_executa_cada_acao}

| Papel / Função       | Responsabilidades                                                  |
| -------------------- |------------------------------------------------------------------- |
| Dev / Tech Lead      | Propor classificação, registar alterações                         |
| AppSec / Segurança   | Validar modelo aplicado, ajustar nível de risco, aplicar matriz   |
| Arquitetura          | Rever implicações técnicas e exposição                            |
| Produto / Gestão     | Aprovar aceitação de risco, rever impacto de exceções             |
| GRC / Compliance     | Assegurar rastreabilidade, validação de critérios normativos      |

> 🧩 O envolvimento de múltiplos papéis responde diretamente aos domínios **Governance** e **Compliance** do OWASP DSOMM.

---

## 🧾 User Stories e Cartões Reutilizáveis {classificacao-aplicacoes:aplicacao-lifecycle#user_stories_e_cartoes_reutilizaveis}

<!--userstory:start-->
### Story: Classificação inicial da aplicação {classificacao-aplicacoes:aplicacao-lifecycle#story_classificacao_inicial_da_aplicacao}

Como responsável técnico, quero classificar a aplicação com base nos eixos E+D+I, para garantir a aplicação proporcional de controlos de segurança.

**Definition of Done:**
- [ ] Modelo aplicado com pontuação 1–3 por eixo
- [ ] Nível L1–L3 definido
- [ ] Documento registado e versionado
- [ ] Controlos mínimos mapeados a partir da matriz ([Matriz de Controlos por Risco](xref:sbd-toe:toe:01-classificacao-aplicacoes:matriz-controlos-por-risco))

> 🔗 Suporta os domínios *Risk* e *Security Requirements* do OWASP DSOMM.
<!--userstory:end-->

<!--userstory:start-->
### Story: Aplicação da matriz de controlo {classificacao-aplicacoes:aplicacao-lifecycle#story_aplicacao_da_matriz_de_controlo}

Como engenheiro de software, quero aplicar a matriz de controlos por nível de criticidade, para garantir que só os requisitos necessários são exigidos.

**Definition of Done:**
- [ ] Matriz consultada para o nível atribuído
- [ ] Requisitos extraídos e convertidos em cartões
- [ ] Exceções justificadas e aprovadas

> 🔗 Cumpre requisitos de proporcionalidade de controlos exigidos no DSOMM.
<!--userstory:end-->

<!--userstory:start-->
### Story: Revisão periódica da classificação {classificacao-aplicacoes:aplicacao-lifecycle#story_revisao_periodica_da_classificacao}

Como AppSec, quero rever a classificação de criticidade sempre que houver alterações significativas, para garantir adequação contínua dos controlos.

**Definition of Done:**
- [ ] Trigger de revisão identificado (ex: nova API, novo dado)
- [ ] Documento atualizado ou validado sem alterações
- [ ] Nível de criticidade mantido ou alterado com justificação

> 🔗 Esta ação reforça a prática de *Continuous Risk Reassessment* do DSOMM.
<!--userstory:end-->

<!--userstory:start-->
### Story: Análise de risco residual {classificacao-aplicacoes:aplicacao-lifecycle#story_analise_de_risco_residual}

Como responsável técnico, quero registar o risco residual após aplicar os controlos definidos, para fundamentar decisões de aceitação ou mitigação.

**Definition of Done:**
- [ ] Identificação de controlos não aplicados
- [ ] Justificação técnica e impacto estimado
- [ ] Aprovação por GRC, produto ou gestão

> 🔗 Contribui para a rastreabilidade e governação de exceções do DSOMM.
<!--userstory:end-->

<!--userstory:start-->
### Story: Validação antes de go-live {classificacao-aplicacoes:aplicacao-lifecycle#story_validacao_antes_de_go_live}

Como QA ou segurança, quero validar que os requisitos aplicáveis por nível de risco estão cumpridos antes da entrada em produção.

**Definition of Done:**
- [ ] Checklist de controlos revisto
- [ ] Evidências documentadas (testes, validações)
- [ ] Aprovação formal de AppSec

<!--userstory:end-->

<!--userstory:start-->
### Story: Mapeamento de ameaças por nível de risco {classificacao-aplicacoes:aplicacao-lifecycle#story_mapeamento_de_ameacas_por_nivel_de_risco}

Como analista de segurança, quero verificar se as ameaças esperadas para o nível de criticidade estão cobertas por controlos aplicados ou exceções rastreáveis.

**Definition of Done:**
- [ ] Ameaças identificadas ([Mapeamento de Ameaças](xref:sbd-toe:toe:01-classificacao-aplicacoes:mapeamento-ameacas-risco))
- [ ] Cobertura por controlo, exceção ou compensação
- [ ] Resultados documentados

<!--userstory:end-->

---

## 📄 Artefactos esperados {classificacao-aplicacoes:aplicacao-lifecycle#artefactos_esperados}

| Artefacto                          | Formato recomendando         | Onde guardar                            |
| ---------------------------------- | ---------------------------- | --------------------------------------- |
| Documento de classificação         | `.md` / `.yaml`              | Repositório `docs/` ou `security/`      |
| Justificação de alterações         | Campo livre no mesmo ficheiro| Commit + PR ou issue                    |
| Matriz de controlo aplicada        | Tabela Markdown              | Incluído no repositório ou wiki         |
| Checklist de conformidade go-live  | `.md` ou formulário aprovado | Anexado a release / PR final            |

---

## ⚖️ Aplicação proporcional por nível de risco (L1–L2–L3) {classificacao-aplicacoes:aplicacao-lifecycle#aplicacao_proporcional_por_nivel_de_risco_l1l2l3}

| Prática                      | L1 (baixo risco)         | L2 (médio risco)               | L3 (elevado risco)                   |
|-----------------------------|--------------------------|-------------------------------|--------------------------------------|
| Classificação inicial       | Manual simplificada      | Avaliada por AppSec           | Formal com validação externa         |
| Aplicação da matriz         | Básica                   | Checklist controlos mínimos   | Checklist + evidência documentada    |
| Revisão periódica           | Anual ou por milestones  | A cada release significativa  | A cada sprint ou evento crítico      |
| Risco residual              | Implícito                | Documentado informalmente     | Justificado, aprovado, rastreável    |
| Validação antes do go-live  | Opcional                 | Recomendado                   | Obrigatório com aprovação formal     |

---

## ✅ Recomendações finais {classificacao-aplicacoes:aplicacao-lifecycle#recomendacoes_finais}

* A classificação de criticidade é o ponto de entrada para a aplicação proporcional do modelo SbD-ToE.
* Deve ser integrada nativamente no ciclo de vida da aplicação e revista periodicamente.
* Os artefactos devem ser rastreáveis, versionados e acessíveis à equipa de segurança, auditoria e gestão de risco.
