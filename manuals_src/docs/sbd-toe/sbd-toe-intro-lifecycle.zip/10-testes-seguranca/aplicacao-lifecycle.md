---
id: aplicacao-lifecycle
title: Aplicação no Ciclo de Vida — Testes de Segurança
description: Integração das práticas de validação contínua nas diferentes fases do ciclo de vida da aplicação.
tags: [ciclo de vida, testes, segurança, integração, validação, sdcl]
sidebar_position: 15
---


# 🧪 Aplicação de Testes de Segurança ao Longo do Ciclo de Vida {testes-seguranca:canon:aplicacao-lifecycle}

Este anexo define **como aplicar de forma sistemática os testes de segurança** descritos no Capítulo 10 ao longo do SDLC — incluindo práticas como SAST, DAST, IAST, fuzzing, regressão e PenTesting — integrando-as com processos ágeis, pipelines CI/CD, critérios de release e gestão de findings.

Inclui artefactos reutilizáveis, user stories e ações esperadas por papel, com variação proporcional por nível de risco da aplicação (L1–L3).

---

## 🧭 Quando aplicar testes de segurança {testes-seguranca:canon:aplicacao-lifecycle#quando_aplicar_testes_de_seguranca}

| Fase / Evento                   | Ação esperada                                                       | Artefacto principal                     |
|----------------------------------|----------------------------------------------------------------------|-----------------------------------------|
| 🔍 Especificação de requisitos   | Identificar requisitos de segurança testáveis (ver Cap. 2)          | Matriz de requisitos + plano de testes  |
| 👩‍💻 Desenvolvimento             | Executar SAST, linters, incluir testes de regressão                 | Findings SAST + histórico de regressões |
| 🔀 Pull request                  | Análise automática com comentários inline (SAST)                    | PR comments + relatório de scanner      |
| ⚙️ Build / CI                    | Executar SCA, SAST, SBOM, testes de regressão                       | Logs + artefactos versionados           |
| 🧪 Ambiente de testes (staging)  | Executar DAST, fuzzing, validações de comportamento                 | Relatórios DAST + logs                  |
| 🚀 Pré-release                   | Verificar critérios de aceitação, findings críticos, exceções       | Checklist de release                    |
| 📦 Pós-release / contínuo        | Fuzzing contínuo, análise comportamental, IAST (se aplicável)       | Monitorização + alertas                 |
| 🔓 PenTesting (validação ofensiva) | Validar a eficácia dos controlos através de testes manuais ofensivos | Relatório técnico de PenTest            |
| ♻️ Sprint review / retro         | Rever findings, atualizar testes, fechar exceções vencidas          | Issues + exceções reavaliadas           |

---

## 👥 Quem executa cada ação {testes-seguranca:canon:aplicacao-lifecycle#quem_executa_cada_acao}

| Papel / Função       | Responsabilidades                                                           |
|----------------------|-----------------------------------------------------------------------------|
| Dev / Dev Lead       | Corrigir findings, escrever testes de regressão, acompanhar resultados      |
| QA / Testes          | Executar testes funcionais com cobertura de segurança, validar critérios    |
| AppSec / Segurança   | Configurar ferramentas, aprovar exceções, gerir findings, validar cobertura |
| CI/CD / DevOps       | Integrar scanners e gates, gerar artefactos de validação                    |
| Produto / Gestão     | Avaliar impacto dos findings, priorizar correções, aceitar riscos residuais |
| Auditor / Pentester  | Executar PenTesting com escopo definido, reportar findings com impacto      |

---

## 🧾 User Stories e Cartões Reutilizáveis {testes-seguranca:canon:aplicacao-lifecycle#user_stories_e_cartoes_reutilizaveis}

### 🟦 Story: Definição da estratégia de testes de segurança {testes-seguranca:canon:aplicacao-lifecycle#story_definicao_da_estrategia_de_testes_de_seguranca}

> Como AppSec, quero definir e manter uma estratégia formal de testes de segurança por aplicação, para garantir cobertura proporcional ao risco e rastreabilidade com requisitos.

**Checklist:**

* [ ] Documento de estratégia criado (por aplicação ou classe)
* [ ] Alinha tipos de testes com requisitos do Cap. 2
* [ ] Define cobertura mínima por risco (L1–L3)
* [ ] Referenciado no plano de testes e atualizado periodicamente


### 🟦 Story: Execução de SAST no pull request {testes-seguranca:canon:aplicacao-lifecycle#story_execucao_de_sast_no_pull_request}

> Como developer, quero que o SAST seja executado automaticamente no meu PR, para que eu possa corrigir problemas antes do merge.

**Checklist:**

* [ ] PR trigger executa SAST com regras mínimas
* [ ] Findings visíveis como comentários inline
* [ ] Resultados rastreados por commit/branch
* [ ] Thresholds definidos por severidade

---

### 🟦 Story: Validação combinada antes do release {testes-seguranca:canon:aplicacao-lifecycle#story_validacao_combinada_antes_do_release}

> Como QA, quero garantir que todos os testes de segurança foram executados antes da entrega, para validar que o software cumpre os requisitos mínimos.

**Checklist:**

* [ ] Checklist de release preenchido
* [ ] Relatórios de SAST, DAST e fuzzing anexados
* [ ] Findings críticos resolvidos ou excecionados
* [ ] Rastreabilidade com requisitos do Cap. 2

---

### 🟦 Story: Gestão de findings com rastreabilidade {testes-seguranca:canon:aplicacao-lifecycle#story_gestao_de_findings_com_rastreabilidade}

> Como AppSec, quero acompanhar o ciclo de vida dos findings de segurança, para garantir que são triados, resolvidos ou aceites formalmente.

**Checklist:**

* [ ] Finding identificado com contexto (tipo, risco, commit)
* [ ] Estado atualizado: novo, aceite, mitigado, resolvido
* [ ] Associado a issue/backlog ou exceção documentada
* [ ] Justificação e prazo definidos

---

### 🟦 Story: Fuzzing de API com base em risco {testes-seguranca:canon:aplicacao-lifecycle#story_fuzzing_de_api_com_base_em_risco}

> Como engenheiro de QA, quero aplicar fuzzing a endpoints críticos, para descobrir falhas que escapam a testes planeados.

**Checklist:**

* [ ] Endpoints classificados por criticidade
* [ ] Perfil de fuzzing configurado (ex: RESTler, ZAP)
* [ ] Ambientes de teste isolados utilizados
* [ ] Anomalias documentadas e entregues à equipa

---

### 🟦 Story: Validação de regressões de segurança {testes-seguranca:canon:aplicacao-lifecycle#story_validacao_de_regressoes_de_seguranca}

> Como developer, quero garantir que uma vulnerabilidade corrigida não é reintroduzida, para evitar falhas repetidas.

**Checklist:**

* [ ] Teste de regressão escrito e automatizado
* [ ] Associado ao finding original
* [ ] Executado em todos os builds
* [ ] Falso positivo descartado com revisão manual


### 🟦 Story: Validação ofensiva por PenTesting {testes-seguranca:canon:aplicacao-lifecycle#story_validacao_ofensiva_por_pentesting}

> Como equipa de segurança, quero validar a eficácia dos controlos automatizados através de PenTesting, para identificar falhas exploráveis antes da produção.

**Checklist:**

* [ ] Escopo definido com base em risco e contexto
* [ ] Planeamento com base em findings existentes
* [ ] Relatório técnico com vetores e impacto
* [ ] Revalidação obrigatória antes do release
* [ ] Findings integrados com backlog e triados

---

## 📄 Templates e artefactos esperados {testes-seguranca:canon:aplicacao-lifecycle#templates_e_artefactos_esperados}

| Artefacto                | Formato recomendado   | Onde guardar / referenciar                  |
|--------------------------|-----------------------|---------------------------------------------|
| Plano de testes de segurança | Markdown             | Diretório `docs/seguranca/` do repositório  |
| Resultados de SAST/DAST  | JSON / HTML / SARIF   | Pipeline CI/CD + PR                         |
| Findings rastreados      | CSV / JSON / sistema  | Backlog ou plataforma (ex: DefectDojo)      |
| Relatório de PenTesting  | PDF / Markdown        | Diretório `auditorias/` ou repositório de segurança |
| Checklist de release     | Markdown / formulário | PR final / Confluence / Jira                |
| Testes de regressão      | Código ou YAML        | Diretório `tests/security/` no repo         |

---

## ⚖️ Aplicação proporcional por nível de risco (L1–L2–L3) {testes-seguranca:canon:aplicacao-lifecycle#aplicacao_proporcional_por_nivel_de_risco_l1l2l3}

| Prática / Momento         | L1 (baixo risco)              | L2 (risco moderado)                | L3 (risco elevado)                          |
|---------------------------|-------------------------------|------------------------------------|---------------------------------------------|
| SAST                      | Build ou PR                   | PR com bloqueio de findings        | PR + baseline de findings + PR comments     |
| DAST                      | Opcional / manual             | Staging com escopo definido        | Automático, com autenticação e cobertura    |
| Fuzzing                   | N/A ou exploratório           | Endpoints prioritários             | Total, com fuzzers configurados             |
| PenTesting                | N/A                           | Ocasional com base em risco        | Obrigatório antes de produção               |
| Regressões                | Casos manuais                 | Automatizados por falha conhecida  | Automáticos com cobertura obrigatória       |
| Gestão de findings        | Issue informal                | Backlog com rastreio               | DefectDojo ou ferramenta estruturada        |
| Critérios de release      | Checklist simplificado        | Findings resolvidos ou aceites     | Nenhum finding crítico sem justificação     |

---

## ✅ Recomendações finais {testes-seguranca:canon:aplicacao-lifecycle#recomendacoes_finais}

* Integrar os testes de segurança nos **fluxos normais de desenvolvimento e qualidade**, sem criar processos paralelos.
* Adaptar a profundidade dos testes ao nível de risco da aplicação (L1–L3).
* Incluir o **PenTesting como reforço final em aplicações L3**, com validação externa e escopo orientado por findings acumulados.
* Reforçar a **visibilidade dos resultados e feedback direto** à equipa, promovendo cultura de melhoria contínua.

> 🔁 A validação de segurança não é uma etapa final — é um **processo contínuo**, que começa na primeira linha de código e acompanha o ciclo de vida da aplicação até à produção.
