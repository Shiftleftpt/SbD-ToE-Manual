---
id: intro
title: Capítulo 13 — Formação e Onboarding Seguro
description: Prescrição de práticas para garantir capacitação mínima em segurança, onboarding validado e cultura técnica contínua.
tags: [formacao, onboarding, cultura, segurança, champions, requisitos]
sidebar_position: 0
---
import Badge from '@site/src/components/Badge';

<div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1rem' }}>
  <Badge color="warning">Capítulo Basilar</Badge>
  <Badge color="info">SAMM: 2 / 3</Badge>
  <Badge color="info">BSIMM: T1, T2, SM1</Badge>
  <Badge color="info">SSDF: PS.2.1–2.3</Badge>
  <Badge color="info">DSOMM: 3 / 3 (Education & Training)</Badge>
  <a href="./canon/10-maturidade.md" style={{ marginLeft: 'auto', fontSize: '0.9rem' }}>📄 Ver análise de maturidade</a>
</div>

# Formação e Onboarding Seguro {formacao-onboarding:intro}

## 🧠 Enquadramento e Rationale {formacao-onboarding:intro#enquadramento_e_rationale}

Este capítulo define como estruturar, aplicar e manter um programa de **formação contínua** e **onboarding técnico seguro**, alinhado com os restantes domínios do manual SbD-ToE.  
Formação eficaz não é opcional: é um **requisito crítico** para a execução segura, consciente e escalável das práticas de segurança.

As equipas devem receber **formação prática, proporcional ao risco**, adequada ao seu perfil e função. Esta formação deve ser:

- **Formal e registada**
- **Validada com evidência**
- **Atualizada continuamente**
- **Aplicada a internos e terceiros**

A ausência de onboarding técnico seguro é uma das principais causas de introdução de riscos, erro humano e falhas na aplicação dos restantes controlos de segurança.

---

## 1. 🧭 O que cobre tecnicamente {formacao-onboarding:intro#1__o_que_cobre_tecnicamente}

Este capítulo cobre:

- Definição de **trilhos de formação por perfil** funcional
- Técnicas de **formação prática e avançada** (labs, CTFs, war rooms, clinics)
- Processos de **onboarding técnico seguro e rastreável**
- Inclusão e validação de **terceiros e fornecedores**
- **Integração da formação nos capítulos técnicos** e no ciclo de vida
- Governação, KPIs e acompanhamento contínuo das ações formativas

---

## 2. 🧪 Prescrição prática: o quê, quem, como, quando, porquê e para quê {formacao-onboarding:intro#2__prescricao_pratica_o_que_quem_como_quando_porque_e_para_que}

### 📌 O que deve ser feito {formacao-onboarding:intro#o_que_deve_ser_feito}

1. Criar e manter **trilhos formativos por função técnica** (ex: Dev, QA, PO, DevOps, AppSec)
2. Estabelecer um **checklist de onboarding técnico seguro**, com validação de conhecimentos e permissões condicionadas
3. Criar e aplicar **quizzes ou avaliações práticas** (ex: revisão de PRs, labs)
4. Incluir **formação mínima obrigatória para terceiros**, com registo e validação
5. Aplicar **técnicas formativas práticas**: CTF, War Room, PR Clinics, threat modeling peer-led
6. Integrar a formação nos **rituais e práticas dos capítulos técnicos**
7. Operacionalizar e sustentar um **programa de Security Champions**
8. Medir e melhorar continuamente com base em **métricas de participação, eficácia e rastreabilidade**

### ⚙️ Como deve ser feito {formacao-onboarding:intro#como_deve_ser_feito}

- Usar os conteúdos e estruturas descritos nos `addon/`: `manual-formacao-por-perfil.md`, `tecnicas-formativas-avancadas.md`, `checklist-onboarding.md`, `formacao-terceiros.md`
- Aplicar formação em **ciclo contínuo**: onboarding, reforço, pós-incidente, por release
- Registar todos os eventos de formação num repositório rastreável (ex: SharePoint, Git, LMS)
- Incluir **formação como critério para permissões técnicas** (ex: acesso a pipelines, produção)
- Utilizar quizzes como parte do onboarding técnico e validação de terceiros

### 📆 Quando aplicar {formacao-onboarding:intro#quando_aplicar}

| Situação                                   | Ação formativa obrigatória                                      |
|--------------------------------------------|-----------------------------------------------------------------|
| Entrada de colaborador interno             | Aplicar checklist de onboarding com validação                   |
| Integração de fornecedor ou contractor     | Aplicar trilho mínimo com quiz e validação formal               |
| Subida de criticidade da aplicação         | Atualizar trilho e reforçar formação                            |
| Introdução de nova tecnologia/processo     | Atualizar conteúdo e comunicar via Champion                     |
| Após incidente de segurança                | Formação dirigida (post-mortem educativo, revisão de decisões)  |
| A cada release relevante ou trimestre      | Reforço prático com labs ou clinics                             |

### 👥 Quem está envolvido {formacao-onboarding:intro#quem_esta_envolvido}

| Papel / Função         | Responsabilidade-chave                                                  |
|------------------------|-------------------------------------------------------------------------|
| AppSec                 | Curadoria de conteúdos, criação de quizzes, facilitação de técnicas     |
| Tech Leads / Champions | Aplicação prática (ex: PR clinics, threat modeling, revisão de labs)   |
| RH / ITSM              | Integração do onboarding nos processos e permissões                     |
| Gestão / PMO           | Visibilidade e reforço institucional, KPIs e cultura de aprendizagem    |
| Terceiros              | Sujeitos aos mesmos critérios com trilho ajustado e registo validado    |

### 🎯 Porquê / Para quê {formacao-onboarding:intro#porque__para_que}

- Garantir execução consistente e segura das práticas SbD-ToE
- Reduzir falhas humanas causadas por desconhecimento
- Aumentar a autonomia das equipas e reduzir dependência de AppSec
- Aumentar o tempo útil entre erros e reforçar cultura de segurança aplicada
- Demonstrar conformidade (NIS2, DORA, SSDF, etc.) com evidência rastreável

---

## 3. 🧮 Aplicação proporcional ao risco {formacao-onboarding:intro#3__aplicacao_proporcional_ao_risco}

A formação segue a mesma lógica de classificação do Capítulo 01 — Gestão de Risco:

| Nível de Risco | Exigência mínima formativa                                               |
|----------------|-------------------------------------------------------------------------|
| L1 – Baixo     | Trilho leve por função + awareness informal                              |
| L2 – Médio     | Trilho completo com validação prática (quiz ou exercício real)           |
| L3 – Elevado   | Formação formal + labs obrigatórios + reforço periódico + Champion ativo |

As exigências formativas devem ser **proporcionais à criticidade da aplicação** em que o colaborador atua.

---

## 4. 🔗 Integração com outros capítulos do manual {formacao-onboarding:intro#4__integracao_com_outros_capitulos_do_manual}

Este capítulo é transversal e operacionaliza práticas dos seguintes capítulos:

- Capítulo 02 — Requisitos de Segurança: validação de conhecimento sobre requisitos aplicáveis
- Capítulo 06 — Desenvolvimento Seguro: clínicas de PR, secure coding e pairing formativo
- Capítulo 07 — CI/CD Seguro: formação prática em pipelines e validações automatizadas
- Capítulo 08 — IaC: validações de segurança, exercícios com scanners, práticas DevOps seguras
- Capítulo 09 — *containers*: labs de hardening, revisão de imagens e práticas de runtime
- Capítulo 10 — Testes de Segurança: práticas com fuzzing, tuning de regras e exploração
- Capítulo 12 — Monitorização: war rooms, alertas reais, incidentes como material formativo
- Capítulo 14 — Governança: cláusulas contratuais, exigências a terceiros, rastreabilidade

---

## 5. 📈 Rastreabilidade, auditoria e métricas {formacao-onboarding:intro#5__rastreabilidade_auditoria_e_metricas}

- Deve existir registo de todas as ações de formação, por pessoa, data, função e nível de risco
- A formação deve estar ligada ao processo de concessão de permissões (ex: Git, CI/CD, produção)
- Os indicadores mínimos incluem (ver `90-kpis-formacao.md`):
  - % de onboarding técnico concluído por equipa
  - % de terceiros com formação validada
  - Número de labs ou quizzes realizados por trimestre
  - Participação em técnicas formativas (CTF, clinics, war rooms)
  - Nível de cobertura de formação por capítulo técnico

---

## 📌 Conclusão {formacao-onboarding:intro#conclusao}

A formação é a ponte entre políticas e prática.  
Sem capacitação contínua, os controlos definidos nos restantes capítulos não se tornam operacionais.

> 📚 Este capítulo transforma a cultura de segurança num **programa prático, escalável e auditável**.
>  
> As equipas deixam de depender da memória ou da vigilância e passam a agir com base em conhecimento aplicado e validado.

