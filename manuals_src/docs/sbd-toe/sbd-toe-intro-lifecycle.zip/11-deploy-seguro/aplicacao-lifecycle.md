---
id: aplicacao-lifecycle
title: Aplicação de Deploy Seguro no Ciclo de Vida
description: Integração das práticas de execução segura, validação e reversibilidade ao longo do SDLC.
tags: [tipo:anexo, grupo:execucao, tema:deploy, reversibilidade, validação, ciclo de vida]
sidebar_position: 15
---


# 🚀 Aplicação de Deploy Seguro ao Longo do Ciclo de Vida {deploy-seguro:canon:aplicacao-lifecycle}

Este anexo define **como aplicar as práticas do Capítulo 11 — Deploy Seguro e Controlo de Execução** ao longo do ciclo de desenvolvimento de software. Assegura que a entrega de funcionalidades em produção é feita com:

- Validação antes da promoção;
- Reversibilidade controlada;
- Rastreabilidade de toggles e owners;
- Monitorização pós-deploy com triggers de rollback.

---

## 🧭 Quando aplicar as práticas {deploy-seguro:canon:aplicacao-lifecycle#quando_aplicar_as_praticas}

| Fase / Evento               | Ação esperada                                                       | Artefacto principal                  |
|----------------------------|----------------------------------------------------------------------|--------------------------------------|
| 🚧 Planeamento da release  | Definir critérios de readiness, rollback e owners                    | Checklist de release                 |
| 🛠 Build de produção       | Gerar artefactos com SBOM e metadata rastreável                     | Artefacto assinado + `release.md`    |
| 🧪 Testes em staging       | Validar funcionalidade, rollback e comportamento com toggles         | Relatório de testes + logs           |
| ✅ Aprovação formal        | Aprovar promoção com base em evidência e readiness                  | Checklist assinado                   |
| 🚀 Execução de deploy      | Logging, toggles ativados, versionamento rastreável                 | Registo no sistema de release        |
| 🔁 Monitorização contínua  | Observar métricas de falha e readiness; configurar triggers          | Dashboard com alertas + logs         |
| ♻️ Rollback                | Executar reversão validada e rastreável, se necessário               | Script de rollback + logs            |

---

## 👥 Quem executa cada ação {deploy-seguro:canon:aplicacao-lifecycle#quem_executa_cada_acao}

| Papel / Função       | Responsabilidades principais                                          |
|----------------------|-----------------------------------------------------------------------|
| Dev / Tech Lead      | Integrar toggles, readiness gates e documentação de release           |
| QA / Release Manager | Validar funcionalidade, rollback e checklist de aprovação             |
| AppSec / Segurança   | Validar contract de release, findings e SBOM                          |
| DevOps / SRE         | Automatizar deploy, rollback, logging e triggers                      |
| Produto / Gestão     | Aprovar go-live com base no risco e evidência                         |

---

## 🧾 User Stories Reutilizáveis {deploy-seguro:canon:aplicacao-lifecycle#user_stories_reutilizaveis}

### 🟦 Aprovação de Deploy com Base em Critérios Técnicos {deploy-seguro:canon:aplicacao-lifecycle#aprovacao_de_deploy_com_base_em_criterios_tecnicos}

> Como gestor de produto, quero aprovar a promoção de código apenas quando os critérios técnicos e de segurança forem cumpridos, para evitar falhas em produção.

**Checklist:**
* [ ] Checklist de release completo
* [ ] Owners registados
* [ ] Todos os findings críticos resolvidos ou com exceção aprovada
* [ ] Plano de rollback testado e versionado

---

### 🟦 Validação Operacional em Staging {deploy-seguro:canon:aplicacao-lifecycle#validacao_operacional_em_staging}

> Como QA, quero validar a versão candidata em ambiente staging, para garantir equivalência funcional com produção e readiness de execução.

**Checklist:**
* [ ] Ambiente staging atualizado e replicável
* [ ] Testes automatizados e manuais concluídos
* [ ] Observabilidade ativa com métricas-chave
* [ ] Log de comportamento e toggles em runtime

---

### 🟦 Teste de Rollback Funcional {deploy-seguro:canon:aplicacao-lifecycle#teste_de_rollback_funcional}

> Como engenheiro DevOps, quero testar rollback antes do go-live, para garantir que a reversibilidade está validada.

**Checklist:**
* [ ] Script de rollback executado com sucesso
* [ ] Reversão da base de dados documentada
* [ ] Restauro de configuração e logs testados
* [ ] Evidência anexada à release

---

### 🟦 Gating de Deploy Automatizado {deploy-seguro:canon:aplicacao-lifecycle#gating_de_deploy_automatizado}

> Como pipeline engineer, quero que o deploy só ocorra quando todos os critérios de readiness forem verificados automaticamente, para evitar erros de promoção.

**Checklist:**
* [ ] Readiness gate ativado no pipeline
* [ ] Verificação de SBOM e validações
* [ ] Falha do gate impede execução
* [ ] Evidência de aprovação documentada

---

### 🟦 Rastreabilidade de Releases e Owners {deploy-seguro:canon:aplicacao-lifecycle#rastreabilidade_de_releases_e_owners}

> Como AppSec, quero garantir que cada release tem rastreabilidade completa de código, toggles, validações e owners, para suportar auditorias e incidentes.

**Checklist:**
* [ ] SBOM gerado e arquivado
* [ ] Artefactos versionados e assinados
* [ ] Owners e validadores identificados
* [ ] Logs de toggles e métricas capturados

---

### 🟦 Monitorização Pós-Deploy e Reação a Incidentes {deploy-seguro:canon:aplicacao-lifecycle#monitorizacao_pos_deploy_e_reacao_a_incidentes}

> Como engenheiro de observabilidade, quero monitorizar continuamente a aplicação e disparar rollback automático em caso de falha crítica.

**Checklist:**
* [ ] Métricas-chave de erro, latência e disponibilidade monitorizadas
* [ ] Triggers de rollback automáticos configurados
* [ ] Alertas enviados para equipa responsável
* [ ] Logs verificados e correlacionados com o deploy

---

## 🧰 Templates e Artefactos Esperados {deploy-seguro:canon:aplicacao-lifecycle#templates_e_artefactos_esperados}

| Artefacto                | Formato recomendado           | Onde guardar / referenciar           |
|--------------------------|-------------------------------|--------------------------------------|
| Checklist de release     | Markdown / Formulário         | Diretório `release/` ou PR final     |
| Release contract         | Markdown                      | `release/contract.md`                |
| Plano de rollback        | Script + Markdown             | `rollback/plan.sh` + `rollback.md`   |
| SBOM da release          | CycloneDX / SPDX JSON         | `artefactos/sbom/`                   |
| Owners e validadores     | YAML / JSON                   | `release/owners.yaml`                |
| Logs e toggles ativados  | Logfiles + Markdown           | Ferramenta de deploy / PR            |

---

## ⚖️ Aplicação proporcional por nível de risco {deploy-seguro:canon:aplicacao-lifecycle#aplicacao_proporcional_por_nivel_de_risco}

| Prática                          | L1 (baixo risco)    | L2 (moderado)          | L3 (elevado)                     |
|----------------------------------|---------------------|------------------------|----------------------------------|
| Checklist de release             | Opcional            | Recomendado            | Obrigatório                      |
| Validação operacional em staging | Manual              | Automatizada + manual  | Automatizada + observável       |
| Plano de rollback                | Documentado         | Testado                | Automatizado e testado           |
| Readiness gates                  | Manual              | Parcialmente automático| Totalmente automatizado          |
| Logging e rastreabilidade        | Básico              | Completo por versão    | Completo + auditável             |
| Triggers de rollback             | Não aplicável       | Monitorização passiva  | Automático com alertas           |

---

## ✅ Recomendações finais {deploy-seguro:canon:aplicacao-lifecycle#recomendacoes_finais}

- Todas as práticas devem produzir **evidência verificável**;
- A **integração em pipelines e processos formais de release** aumenta a segurança e auditabilidade;
- A **reversibilidade testada e documentada** é um pré-requisito essencial para qualquer entrega segura.

> 📌 Um deploy seguro é mais do que uma ação técnica: é uma **decisão crítica de risco**. Este capítulo define as práticas necessárias para que essa decisão seja segura, rastreável e reversível.
