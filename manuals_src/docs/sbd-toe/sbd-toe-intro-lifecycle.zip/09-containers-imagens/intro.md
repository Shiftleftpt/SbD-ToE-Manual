---
id: intro
title: containers e Execução Isolada
description: Princípios, práticas e controlos para garantir execução segura, validada e rastreável em ambientes containerizados
tags: [containers, isolamento, execução, imagens, cicd, opa, kubernetes, trust, DSOMM]
---
import Badge from '@site/src/components/Badge';

<div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1rem' }}>
  <Badge color="warning">Capítulo Basilar</Badge>
  <Badge color="info">SAMM: 2 / 3</Badge>
  <Badge color="info">BSIMM: SE2.1, SE2.5, CMVM2.4</Badge>
  <Badge color="info">SSDF: PW.6, RV.1, RV.4</Badge>
  <Badge color="info">SLSA: Nível 4 / 4</Badge>
  <Badge color="info">DSOMM: 3 / 4 (média)</Badge>
  <a href="./canon/10-maturidade.md" style={{ marginLeft: 'auto', fontSize: '0.9rem' }}>📄 Ver análise de maturidade</a>
</div>

:::caution Capítulo Basilar

Este capítulo é considerado **basilar** no modelo SbD-ToE. A sua não aplicação **inviabiliza a confiança na execução segura de pipelines, aplicações e ambientes containerizados**. Sem controlo de execução, não há segurança de runtime.

:::

# *containers* e Execução Isolada {containers-imagens:intro}

## 🧠 Enquadramento e Rationale {containers-imagens:intro#enquadramento_e_rationale}

A execução de código em *containers* é hoje ubíqua — desde pipelines de CI/CD até microserviços em produção. Apesar de oferecem agilidade e portabilidade, *containers* introduzem **riscos significativos** caso não sejam devidamente validados e isolados:

- **Execução de imagens adulteradas ou não confiáveis**
- **Falta de controlo sobre permissões e isolamento de processo**
- **Ausência de rastreabilidade sobre o que foi executado e porquê**
- **Ambientes de execução (runners) partilhados ou mal configurados**

Garantir que os *containers* são **seguros, validados, rastreáveis e sujeitos a políticas de execução** é essencial para a segurança operacional e de desenvolvimento.

---

## 1. 🧭 O que cobre tecnicamente {containers-imagens:intro#1__o_que_cobre_tecnicamente}

Este capítulo define práticas e controlos para garantir **execução segura, validada e isolada de aplicações, pipelines e ambientes de runtime** baseados em *containers*. Cobre aspetos como:

- Escolha e validação de imagens base seguras
- Execução em ambientes controlados (runners, jobs, serviços)
- Assinatura e verificação de imagens
- Hardening e minimização de runtime
- Aplicação de políticas de execução (OPA, Kyverno)
- Integração com Kubernetes e controlo no runtime
- Geração de SBOM e rastreabilidade de execução

---

## 2. 🧪 Prescrição prática: o quê, quem, como, quando, porquê e para quê {containers-imagens:intro#2__prescricao_pratica_o_que_quem_como_quando_porque_e_para_que}

### 📌 O que deve ser feito {containers-imagens:intro#o_que_deve_ser_feito}

1. **Selecionar e aprovar imagens base seguras** para uso em pipelines e produção;
2. **Validar a cadeia de confiança** das imagens (assinatura, origem, proveniência);
3. **Executar *containers* apenas em ambientes isolados e controlados** (runners dedicados, namespaces restritos, sem privilégios excessivos);
4. **Aplicar políticas de execução e runtime** com OPA/Kyverno/PSP;
5. **Gerar e manter SBOM dos *containers*** utilizados;
6. **Detetar e tratar vulnerabilidades em runtime**;
7. **Registar e auditar execuções** com integridade e rastreabilidade.

---

### ⚙️ Como deve ser feito {containers-imagens:intro#como_deve_ser_feito}

- Usar imagens base minimalistas (ex: distroless, alpine) validadas e mantidas;
- Adotar ferramentas de assinatura como Cosign + Rekor para verificação de integridade;
- Utilizar scanners de vulnerabilidades integrados no CI/CD para validar imagens antes do uso;
- Executar *containers* com runtime restritivo (user não root, sem capabilities extra, sem montagem de volumes privilegiados);
- Definir políticas de execução com OPA/Kyverno, incluindo restrições de labels, permissões, imagem e namespace;
- Usar sidecars de observabilidade e enforcement, quando aplicável;
- Implementar SBOM de *containers* com ferramentas como Syft, e rastrear alterações;
- Registar execuções em logs imutáveis ou auditáveis.

---

### 📆 Quando aplicar {containers-imagens:intro#quando_aplicar}

- **Durante o desenho da pipeline CI/CD**, especialmente se recorre a *containers* para execução de jobs;
- **Na definição de imagens base** autorizadas;
- **Antes de lançar para produção**, como fase de validação de runtime;
- **Em cada nova versão de imagem**, durante o processo de build;
- **Sempre que se alterar a arquitetura de execução (ex: migração para Kubernetes)**;
- **Em resposta a vulnerabilidades públicas (ex: CVEs em imagens Docker)**.

---

### 👥 Quem está envolvido e como {containers-imagens:intro#quem_esta_envolvido_e_como}

| Papel                 | Contributo                                                                        |
|-----------------------|------------------------------------------------------------------------------------|
| DevOps / Plataforma   | Define imagens aprovadas, runners seguros, enforcement via OPA/Kyverno             |
| Equipa de Desenvolvimento | Utiliza imagens validadas, aplica controlos nos *containers*, integra SBOM          |
| AppSec / Segurança    | Valida cadeia de confiança, controlo de execução, integra scanners de runtime     |
| Infraestrutura        | Assegura isolamento (cgroups, namespaces, policies) e execução segura em Kubernetes|
| GRC / Conformidade    | Garante rastreabilidade, políticas formais, evidência de execução segura          |

---

### 🎯 Porquê / Para quê {containers-imagens:intro#porque__para_que}

- **Evitar execução de código não verificado** ou adulterado;
- **Reduzir superfície de ataque** em pipelines e ambientes de produção;
- **Aumentar rastreabilidade e confiança na execução de software**;
- **Cumprir requisitos normativos e regulatórios (ex: SLSA, SSDF, NIS2)**;
- **Proteger a organização contra compromissos via pipeline ou infraestrutura contaminada**;
- **Permitir auditoria clara e objetiva de execução e runtime**;
- **Apoiar o modelo de confiança zero (Zero Trust Execution)**.

