---
id: aplicacao-lifecycle
title: Aplicação de Segurança de Containers ao Ciclo de Vida
description: Integração prática das práticas de execução segura, validação, assinatura e rastreabilidade de containers no ciclo de desenvolvimento
tags: [lifecycle, containers, isolamento, assinatura, sbom, cicd, dsomm, kubernetes]
sidebar_position: 15
---

# 🛠️ Aplicação de Segurança de Containers ao Longo do Ciclo de Vida {containers-imagens:canon:aplicacao-lifecycle}

Este anexo define **como aplicar sistematicamente as práticas de segurança de containers, imagens e execução isolada** ao longo do ciclo de desenvolvimento e operação.  
As práticas incluem construção segura, validação, assinatura, políticas de runtime, rastreabilidade e integração com Kubernetes — em conformidade com o Capítulo 09.

O objetivo é garantir que estas práticas são integradas no dia-a-dia das equipas, com artefactos rastreáveis, user stories reutilizáveis e aplicação proporcional por nível de risco.

---

## 🧭 Quando aplicar práticas de containers, imagens e execução segura {containers-imagens:canon:aplicacao-lifecycle#quando_aplicar_praticas_de_containers_imagens_e_execucao_segura}

| Fase / Evento                    | Ação esperada                                                                           | Artefacto principal                        |
|----------------------------------|------------------------------------------------------------------------------------------|---------------------------------------------|
| 🚧 Início de projeto             | Selecionar imagens base autorizadas e definir política de proveniência                  | `base-images.yaml`                          |
| 🛠️ Definição da pipeline        | Integrar steps de verificação (SBOM, assinatura, CVEs, OPA)                             | `ci.yml`, `rego/`, `opa-policies/`          |
| 🔨 Build de imagem               | Usar Dockerfile seguro, UID não-root, gerar SBOM e evitar dependências inseguras        | Dockerfile validado, `.sbom.json`           |
| 🔏 Assinatura de imagem          | Assinar imagem com Cosign e publicar proveniência no repositório                       | `.sig`, `rekor entry`, `cosign.pub`         |
| 🧪 Execução controlada (CI/CD)   | Validar imagem, aplicar políticas OPA, isolar runners e pods                            | Logs de execução, `policy.yaml`, CI logs    |
| 🧾 Go-live / release             | Confirmar rastreabilidade, SBOM e assinatura, aplicar checklist de segurança            | `release-checklist.md`                      |
| 🔁 Sprint / manutenção contínua  | Atualizar imagens base, rever findings, eliminar imagens obsoletas                      | PRs de atualização, relatório de ciclo de vida |
| ⚠️ Vulnerabilidade nova         | Avaliar impacto da CVE e aplicar fix ou exceção documentada                            | Issue de segurança, `excecoes.yaml`         |

---

## 👥 Quem executa cada ação {containers-imagens:canon:aplicacao-lifecycle#quem_executa_cada_acao}

| Papel / Função       | Responsabilidades                                                                 |
|----------------------|------------------------------------------------------------------------------------|
| Dev / Dev Lead       | Usar imagens seguras, seguir política de construção, executar em ambientes controlados |
| AppSec / Segurança   | Validar assinatura, CVEs, políticas de execução, rastreabilidade e SBOM            |
| CI/CD / DevOps       | Integrar scanners, OPA, runners isolados, assinatura e validações no pipeline      |
| Plataforma / Kubernetes | Garantir configuração de runtime segura, RBAC, e aplicação de policies no cluster |
| GRC / Conformidade   | Exigir checklist de execução segura, registo de assinatura e prova de política aplicada |

---

## 🧾 User Stories e Cartões Reutilizáveis {containers-imagens:canon:aplicacao-lifecycle#user_stories_e_cartoes_reutilizaveis}

Estes exemplos podem ser usados em boards, pipelines ou processos de entrega para reforçar a adoção prática das práticas prescritas.

---

### 🟦 Story: Build de imagem segura {containers-imagens:canon:aplicacao-lifecycle#story_build_de_imagem_segura}

> Como DevOps, quero construir imagens a partir de bases autorizadas e sem root, para garantir que o runtime é seguro.

**Checklist:**

* [ ] Imagem base presente em `base-images.yaml`
* [ ] Dockerfile sem instruções privilegiadas
* [ ] UID definido e sem `USER root`
* [ ] `no-new-privileges: true` aplicado

---

### 🟦 Story: Assinatura de imagem com Cosign {containers-imagens:canon:aplicacao-lifecycle#story_assinatura_de_imagem_com_cosign}

> Como engenheiro de CI/CD, quero assinar todas as imagens geradas com Cosign, para garantir a proveniência.

**Checklist:**

* [ ] Cosign executado no final do build
* [ ] Chave privada gerida em segurança
* [ ] Proveniência publicada (Rekor/OCI)
* [ ] Artefacto `.sig` incluído na imagem

---

### 🟦 Story: Validação automática da assinatura {containers-imagens:canon:aplicacao-lifecycle#story_validacao_automatica_da_assinatura}

> Como DevOps, quero que a pipeline valide a assinatura da imagem antes do deploy, para impedir uso de artefactos não confiáveis.

**Checklist:**

* [ ] Cosign verify incluído no step de deploy
* [ ] CI falha se a assinatura estiver ausente ou inválida
* [ ] Logs do processo arquivados

---

### 🟦 Story: Aplicação de políticas de execução {containers-imagens:canon:aplicacao-lifecycle#story_aplicacao_de_politicas_de_execucao}

> Como engenheiro de plataforma, quero aplicar políticas OPA/Kyverno para garantir que só imagens seguras são executadas.

**Checklist:**

* [ ] Políticas implementadas no cluster (OPA, Kyverno ou equivalente)
* [ ] Regras para UID, root, hostPath, capabilities
* [ ] Blocos de execução registrados e auditáveis

---

### 🟦 Story: Geração de SBOM automática {containers-imagens:canon:aplicacao-lifecycle#story_geracao_de_sbom_automatica}

> Como DevOps, quero que cada imagem contenha um SBOM completo, para garantir rastreabilidade e visibilidade de componentes.

**Checklist:**

* [ ] SBOM gerado com Syft, Trivy ou equivalente
* [ ] Inclui dependências transitivas
* [ ] Guardado como anotação ou artefacto versionado
* [ ] Disponível para AppSec/GRC

---

### 🟦 Story: Scanner de vulnerabilidades na pipeline {containers-imagens:canon:aplicacao-lifecycle#story_scanner_de_vulnerabilidades_na_pipeline}

> Como DevOps, quero que a pipeline verifique vulnerabilidades nas imagens antes do deploy, para prevenir CVEs em produção.

**Checklist:**

* [ ] Scanner SCA ativado no pipeline
* [ ] Threshold de severidade definido
* [ ] Build falha em caso de findings não aceites
* [ ] Relatório anexado ao job

---

### 🟦 Story: Justificação de exceções de findings {containers-imagens:canon:aplicacao-lifecycle#story_justificacao_de_excecoes_de_findings}

> Como developer, quero justificar findings críticos com risco aceite, para poder avançar com o deploy de forma rastreável.

**Checklist:**

* [ ] Finding referenciado por ID e severidade
* [ ] Justificação técnica e risco documentado
* [ ] Prazo de validade definido
* [ ] Aprovado por AppSec e GRC

---

### 🟦 Story: Revalidação de exceções vencidas {containers-imagens:canon:aplicacao-lifecycle#story_revalidacao_de_excecoes_vencidas}

> Como AppSec, quero verificar periodicamente as exceções vencidas, para forçar mitigação ou correção atualizada.

**Checklist:**

* [ ] Exceções com data de validade
* [ ] Painel ou script de monitorização
* [ ] Issue de revalidação automática
* [ ] Correção ou renovação registada

---

### 🟦 Story: Atualização periódica de imagens base {containers-imagens:canon:aplicacao-lifecycle#story_atualizacao_periodica_de_imagens_base}

> Como Dev, quero saber se a minha imagem base está desatualizada, para garantir proteção contra vulnerabilidades conhecidas.

**Checklist:**

* [ ] Política de TTL definida (ex: 30 dias)
* [ ] Verificação automatizada de datas
* [ ] Atualização integrada como PR com SBOM e validação
* [ ] Changelog documentado

---

### 🟦 Story: Retenção e obsolescência de imagens {containers-imagens:canon:aplicacao-lifecycle#story_retencao_e_obsolescencia_de_imagens}

> Como engenheiro de registo, quero eliminar imagens antigas e não usadas, para reduzir risco de execução de artefactos obsoletos.

**Checklist:**

* [ ] Política de retenção definida (ex: 90 dias, tags permitidas)
* [ ] Cleanup automático com logs
* [ ] Imagens removidas são listadas por CI/CD
* [ ] Histórico mantido para auditoria

---

### 🟦 Story: Execução segura em Kubernetes {containers-imagens:canon:aplicacao-lifecycle#story_execucao_segura_em_kubernetes}

> Como plataforma, quero que todos os containers sejam executados com isolamento e runtime restrito, para minimizar exposição.

**Checklist:**

* [ ] `runAsNonRoot: true` aplicado
* [ ] `seccompProfile`, `readOnlyRootFS`, `capDrop` configurados
* [ ] `hostPID`, `hostNetwork`, `hostIPC` desativados
* [ ] Enforcement validado por Admission Controller

---

### 🟦 Story: Rastreabilidade e release segura {containers-imagens:canon:aplicacao-lifecycle#story_rastreabilidade_e_release_segura}

> Como GRC, quero garantir que cada release contenha prova de proveniência, SBOM e conformidade com política de execução.

**Checklist:**

* [ ] Imagem usada foi assinada e validada
* [ ] SBOM incluído como artefacto
* [ ] Checklist de release preenchido e aprovado
* [ ] Logs de enforcement arquivados


## ⚖️ Aplicação proporcional por nível de risco (L1–L2–L3) {containers-imagens:canon:aplicacao-lifecycle#aplicacao_proporcional_por_nivel_de_risco_l1l2l3}

| Prática                        | L1 (baixo risco)              | L2 (risco moderado)           | L3 (risco elevado)                            |
|-------------------------------|-------------------------------|-------------------------------|-----------------------------------------------|
| Imagem base autorizada        | Recomendado                   | Obrigatório                   | Obrigatório + rastreada                       |
| Execução não-root             | Recomendado                   | Obrigatório                   | Obrigatório + validado em runtime             |
| Assinatura de imagem          | Opcional                      | Obrigatória                   | Obrigatória + validação contínua              |
| Políticas de execução (OPA)   | Recomendado                   | Aplicadas em CI ou pre-prod   | Aplicadas em todos os ambientes               |
| SBOM                          | Gerado no build               | Guardado com release          | Verificado e rastreável                       |
| Retenção de imagens           | Manual                        | Política definida             | Automatizada com auditoria                    |

---

## ✅ Recomendações finais {containers-imagens:canon:aplicacao-lifecycle#recomendacoes_finais}

* As práticas aqui descritas devem ser **incorporadas no fluxo normal de desenvolvimento e entrega**, com suporte em CI/CD e governança de infraestrutura.
* Os artefactos devem ser **versionados, validados e rastreáveis**, mesmo que gerados automaticamente.
* A proporcionalidade por nível de risco deve ser aplicada com base na classificação definida no Capítulo 01.

> 🔐 A segurança de containers começa no build mas prolonga-se até ao runtime — **tornando este capítulo essencial para ambientes modernos baseados em execução isolada.**
