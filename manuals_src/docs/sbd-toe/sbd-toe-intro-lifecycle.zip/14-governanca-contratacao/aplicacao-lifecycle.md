---
id: aplicacao-lifecycle
title: Aplicação das Práticas de Governança no Ciclo de Vida
sidebar_position: 15
description: Exemplos e recomendações práticas para aplicar a governação de segurança em todo o ciclo de vida de software
tags: [governança, ciclo de vida, exceções, requisitos, contratos, terceiros, rastreabilidade, validação]
---


# 🧭 Aplicação das Práticas de Governança no Ciclo de Vida {governanca-contratacao:canon:aplicacao-lifecycle}

Este anexo prescreve **como aplicar sistematicamente as práticas de governança e contratação ao longo do ciclo de vida de projetos e produtos**, garantindo rastreabilidade de decisões, aplicação proporcional de requisitos, validação formal de exceções, e controlo de terceiros.

---

## 🗓️ Quando aplicar as práticas de governança e contratação {governanca-contratacao:canon:aplicacao-lifecycle#quando_aplicar_as_praticas_de_governanca_e_contratacao}

| Fase / Evento                       | Ação esperada                                                               | Artefacto principal                   |
| ----------------------------------- | --------------------------------------------------------------------------- | ------------------------------------- |
| 🚀 Início de projeto                | Definir critérios de risco e requisitos aplicáveis                          | Documento de classificação / matriz   |
| 📄 Planeamento de contrato          | Incluir cláusulas de segurança baseadas em requisitos e perfil de risco     | Template contratual + rastreabilidade |
| 📥 Integração de terceiro           | Aplicar checklist de onboarding + validação de conformidade com requisitos  | Formulário de integração + registo    |
| 🔍 Detecção de não conformidade     | Avaliar exceção, registar justificação, validade, owner e compensadores     | Ficheiro `excecoes.yaml`              |
| 🧪 Validação de release             | Verificar aplicação efetiva dos requisitos exigidos + exceções justificadas | Checklist de release                  |
| 📊 Reuniões de controlo / auditoria | Rever aplicação de requisitos e exceções em vigor + KPIs                    | Relatório de conformidade / dashboard |

---

## 👥 Responsabilidades e intervenientes {governanca-contratacao:canon:aplicacao-lifecycle#responsabilidades_e_intervenientes}

| Função / Papel         | Responsabilidades principais                                                 |
| ---------------------- | ---------------------------------------------------------------------------- |
| Owner de projeto       | Submeter exceções, garantir conformidade contratual, apoiar auditoria        |
| AppSec / Segurança     | Validar requisitos, exceções, revisão de conformidade                        |
| Equipa técnica         | Aplicar requisitos, registar justificativos e artefactos                     |
| Gestão / Produto       | Aprovar riscos residuais e exceções justificadas                             |
| Procurement / Jurídico | Assegurar tradução contratual dos requisitos e cláusulas                     |
| GRC / Compliance       | Validar rastreabilidade, evidências e aplicação de políticas organizacionais |

---

## 📋 User Stories e Ações Reutilizáveis {governanca-contratacao:canon:aplicacao-lifecycle#user_stories_e_acoes_reutilizaveis}

### 🟦 Story: Definição do modelo de governação e owners {governanca-contratacao:canon:aplicacao-lifecycle#story_definicao_do_modelo_de_governacao_e_owners}

> Como equipa de segurança, quero definir um modelo de governação com owners atribuídos e fluxo de exceções, para garantir controlo e accountability formal.

**Checklist:**

* [ ] Owner responsável por segurança do projeto nomeado  
* [ ] Ciclo de exceções documentado (submissão → decisão → validade)  
* [ ] Tabela de responsabilidades publicada e acessível  
* [ ] Integração com documentos organizacionais ou wiki  

---

### 🟦 Story: Submissão de exceção a requisito {governanca-contratacao:canon:aplicacao-lifecycle#story_submissao_de_excecao_a_requisito}

> Como owner de projeto, quero registar uma exceção com justificação e validade, para garantir rastreabilidade e aprovação formal.

**Checklist:**

* [ ] Requisito não aplicável claramente identificado  
* [ ] Justificação técnica e negocial  
* [ ] Proposta de compensação  
* [ ] Validade definida + owner nomeado  

---

### 🟦 Story: Validação formal de exceção {governanca-contratacao:canon:aplicacao-lifecycle#story_validacao_formal_de_excecao}

> Como AppSec, quero aprovar ou rejeitar exceções a requisitos, para garantir conformidade e compensação adequada de risco.

**Checklist:**

* [ ] Verificação de documentação  
* [ ] Avaliação de risco residual  
* [ ] Aprovação formal com registo  

---

### 🟦 Story: Inclusão de cláusulas contratuais de segurança {governanca-contratacao:canon:aplicacao-lifecycle#story_inclusao_de_clausulas_contratuais_de_seguranca}

> Como Procurement ou Jurídico, quero incluir cláusulas contratuais com requisitos de segurança no contrato de fornecimento, para garantir enforcement legal.

**Checklist:**

* [ ] Cláusulas incluídas no contrato base ou adenda técnica  
* [ ] Correspondência com requisitos de segurança do projeto  
* [ ] Revisão jurídica e validação AppSec concluídas  
* [ ] Registo versionado da versão contratual final  

---

### 🟦 Story: Integração de fornecedor {governanca-contratacao:canon:aplicacao-lifecycle#story_integracao_de_fornecedor}

> Como equipa de procurement, quero validar se um fornecedor cumpre os requisitos de segurança, para garantir onboarding conforme.

**Checklist:**

* [ ] Classificação de risco do sistema associada  
* [ ] Checklist e questionário preenchidos  
* [ ] Aprovação conjunta AppSec + Procurement  

---

### 🟦 Story: Rastreabilidade de requisitos e contratos {governanca-contratacao:canon:aplicacao-lifecycle#story_rastreabilidade_de_requisitos_e_contratos}

> Como GRC, quero garantir que os requisitos aplicados a cada sistema estão refletidos em cláusulas contratuais, para suportar auditoria.

**Checklist:**

* [ ] Matriz de requisitos mapeada para cláusulas  
* [ ] Registo de documentos contratuais e owners  
* [ ] Evidência de conformidade / exceções por sistema  

---

### 🟦 Story: Validação de release com exceções {governanca-contratacao:canon:aplicacao-lifecycle#story_validacao_de_release_com_excecoes}

> Como QA ou AppSec, quero verificar se todas as exceções estão dentro do prazo e justificadas, antes da entrega do produto.

**Checklist:**

* [ ] Checklist de release atualizado  
* [ ] Referência a ficheiro de exceções  
* [ ] Aprovação por owner / AppSec  

---

### 🟦 Story: Validação contínua de fornecedores e exceções {governanca-contratacao:canon:aplicacao-lifecycle#story_validacao_continua_de_fornecedores_e_excecoes}

> Como GRC, quero rever periodicamente os fornecedores ativos e exceções aprovadas, para garantir que continuam válidos e conformes com os critérios de risco.

**Checklist:**

* [ ] Lista de fornecedores atualizada com datas de última revisão  
* [ ] Exceções com validade expiradas notificadas  
* [ ] Relatório de conformidade entregue à direção ou board  
* [ ] Casos não conformes encaminhados para revalidação  

---

### 🟦 Story: Análise de maturidade e indicadores (KPIs) {governanca-contratacao:canon:aplicacao-lifecycle#story_analise_de_maturidade_e_indicadores_kpis}

> Como equipa de segurança ou gestão, quero calcular o nível de maturidade de governança e os KPIs definidos, para guiar ações corretivas e melhoria contínua.

**Checklist:**

* [ ] Modelo de maturidade selecionado e contextualizado (ex: SAMM, DSOMM)  
* [ ] Indicadores aplicados ao domínio de governança  
* [ ] Painel com métricas atualizado trimestralmente  
* [ ] Integração com portal de reporting ou ferramentas de GRC  

---

### 🟦 Story: Tratamento de exceções históricas e governação legada {governanca-contratacao:canon:aplicacao-lifecycle#story_tratamento_de_excecoes_historicas_e_governacao_legada}

> Como GRC, quero identificar exceções técnicas e contratuais anteriores ao modelo atual, para decidir se devem ser aceites, atualizadas ou eliminadas.

**Checklist:**

* [ ] Inventário de práticas legadas e exceções sem owner definido  
* [ ] Análise de risco técnico e organizacional  
* [ ] Plano de transição ou aceitação formal documentado  
* [ ] Justificações integradas no registo de exceções atual (`excecoes.yaml`)  

---

## 📄 Templates e Artefactos Esperados {governanca-contratacao:canon:aplicacao-lifecycle#templates_e_artefactos_esperados}

| Artefacto                      | Formato sugerido       | Local / Repositório                            |
| ------------------------------ | ---------------------- | ---------------------------------------------- |
| Ficheiro de exceções           | `excecoes.yaml`        | Diretório `security/` ou `governanca/` no repo |
| Checklist de onboarding        | Formulário + checklist | Confluence, Git ou ferramenta de integração    |
| Matriz de requisitos por risco | Markdown / XLSX        | Diretório `docs/` ou wiki                      |
| Cláusulas contratuais          | Word / PDF             | Diretório legal / partilha segura              |
| Checklist de release           | Markdown               | Repositório + pull request final               |
| Dashboard de exceções          | PowerBI / Grafana      | Portal interno / integração com GRC            |

---

## ⚖️ Aplicação proporcional por nível de risco (L1–L2–L3) {governanca-contratacao:canon:aplicacao-lifecycle#aplicacao_proporcional_por_nivel_de_risco_l1l2l3}

| Prática                    | L1 (baixo risco)      | L2 (médio risco)          | L3 (elevado risco)                      |
| -------------------------- | --------------------- | ------------------------- | --------------------------------------- |
| Exceções                   | Comentário informal   | Issue documentado         | Ficheiro estruturado + owner + validade |
| Cláusulas contratuais      | Genéricas / opcionais | Requisitos base incluídos | Cláusulas específicas + rastreabilidade |
| Checklist onboarding       | Opcional              | Obrigatório para L2+      | Obrigatório + validação AppSec/GRC      |
| Rastreabilidade requisitos | Manual / parcial      | Tabela por sistema        | Matriz completa + contrato referenciado |
| Validação release          | Livre / por owner     | Checklist de conformidade | Validação formal + registo de exceções  |

---

## ✅ Recomendações finais {governanca-contratacao:canon:aplicacao-lifecycle#recomendacoes_finais}

* A aplicação de governança deve estar integrada com o ciclo de vida desde o início do projeto.
* As exceções devem ser tratadas como mecanismo formal de gestão de risco, com validade e compensação.
* Todos os artefactos devem ser versionados e auditáveis.
* A gestão de terceiros deve seguir processos definidos e ser validada periodicamente.
* Os KPIs derivados destes processos devem ser integrados na gestão de segurança organizacional (ver Cap. 14.30).

> 📌 A adoção sistemática destas práticas garante conformidade, rastreabilidade e maturidade nos processos de segurança organizacional.
