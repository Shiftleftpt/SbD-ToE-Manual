---
id: intro
title: Governança e Contratação
description: Estabelecimento de responsabilidades, aprovações, políticas e cláusulas contratuais para suportar a segurança by design
tags: [governanca, contratacao, excecoes, aprovacao, ciclo de vida, sbom]
---
import Badge from '@site/src/components/Badge';

<div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1rem' }}>
  <Badge color="warning">Capítulo Basilar</Badge>
  <Badge color="info">SAMM: 2 / 3</Badge>
  <Badge color="info">BSIMM: SE2, CP1</Badge>
  <Badge color="info">SSDF: PO.1.1, PO.3.1, RV.1.1, RV.2.2</Badge>
  <Badge color="info">SLSA: Nível 2 / 4</Badge>
  <Badge color="info">DSOMM: 4 / 5 (Governance, 3rd Party)</Badge>
  <a href="./canon/10-maturidade.md" style={{ marginLeft: 'auto', fontSize: '0.9rem' }}>📄 Ver análise de maturidade</a>
</div>


# 🧭 Enquadramento e Rationale {governanca-contratacao:intro}

A aplicação de práticas de segurança by design requer **mecanismos de governança eficazes**, incluindo:

- Definição clara de **responsabilidades** e **papéis críticos** ao longo do ciclo de vida
- Existência de **processos formais de aprovação**, exceção e validação
- Inclusão de **cláusulas contratuais** de segurança na contratação de serviços, fornecedores e software
- Rastreabilidade das decisões, entregáveis e validações

Este capítulo prescreve os elementos fundamentais de **governança organizacional e contratual** que suportam a adoção de práticas de segurança em desenvolvimento, operação e aquisição de software.

> ⚠️ Este capítulo **não trata da governação da aplicação do modelo SbD-ToE em si** (ex: validação dos seus checklists ou controlo transversal de adoção). Esse tema será abordado num capítulo próprio (em preparação).

---

## 1. 🎯 O que cobre tecnicamente {governanca-contratacao:intro#1__o_que_cobre_tecnicamente}

Este capítulo abrange:

- Nomeação e responsabilização de *approvers*, *validators* e *owners*
- Definição de processos para:
  - Aprovação de exceções a requisitos de segurança
  - Revisão de entregáveis (ex: SBOM, testes, validações)
  - Onboarding de fornecedores com validação de segurança
- Inclusão de cláusulas contratuais mínimas de segurança
- Requisitos documentais e de evidência formal
- Ciclo de vida de aprovação de releases em função do risco

---

## 2. 🧪 Prescrição prática — o quê, como, quando, por quem, e para quê {governanca-contratacao:intro#2__prescricao_pratica__o_que_como_quando_por_quem_e_para_que}

### 📌 O que deve ser feito {governanca-contratacao:intro#o_que_deve_ser_feito}

1. Estabelecer papéis e responsabilidades formais para aprovação, revisão e validação
2. Definir e publicar um processo de exceção de segurança com base em risco
3. Incluir cláusulas contratuais de segurança em todas as contratações relevantes
4. Garantir que entregáveis de segurança (ex: SBOM, planos de testes) são validados formalmente
5. Aprovar formalmente releases e onboarding de fornecedores críticos

---

### ⚙️ Como deve ser feito {governanca-contratacao:intro#como_deve_ser_feito}

- Usar **templates** ou checklists formais com registo de decisão (ver addons)
- Integrar o fluxo de aprovações com ferramentas de gestão de desenvolvimento (Jira, GitHub, etc.)
- Incluir cláusulas contratuais-padrão (ver políticas em `60-policies-relevantes.md`)
- Rastrear decisões e validações no repositório ou ferramenta de gestão de risco
- Documentar justificações e evidência sempre que um controlo não for aplicado

---

### 📆 Quando aplicar {governanca-contratacao:intro#quando_aplicar}

- Antes de qualquer release para produção
- Sempre que for detetada uma falha de controlo crítico
- No início de projetos que envolvam fornecedores, outsourcing ou serviços terceiros
- Ao identificar exceções justificadas a requisitos ou controlos mínimos
- Em auditorias ou processos formais de validação de segurança

---

### 👥 Quem está envolvido e como {governanca-contratacao:intro#quem_esta_envolvido_e_como}

| Papel / Função            | Contributo principal                                                  |
|---------------------------|------------------------------------------------------------------------|
| Equipa de Segurança       | Define papéis críticos, validações e coordena aprovações              |
| Gestão / Direção Técnica  | Aprova exceções e releases com base no risco                          |
| Jurídico / Contratação    | Integra cláusulas de segurança em contratos                           |
| Equipa de Desenvolvimento | Fornece evidência e executa práticas alinhadas com o risco            |
| Fornecedores / Terceiros  | Têm responsabilidades explícitas definidas contratualmente            |

---

### 🎯 Porquê / Para quê {governanca-contratacao:intro#porque__para_que}

- Garantir que decisões críticas têm **validação formal e responsável**
- Evitar que riscos sejam assumidos implicitamente sem visibilidade
- Reduzir a exposição a falhas contratuais, técnicas ou legais
- Assegurar **governança efetiva da segurança no ciclo de vida**
- Estabelecer uma cultura de **accountability e rastreabilidade** entre equipas

---

## 🔍 O que pode ser feito mais (e porquê) {governanca-contratacao:intro#o_que_pode_ser_feito_mais_e_porque}

- Avaliar exceções em função de **matriz de risco e impacto**
- Atribuir *Security Owners* por projeto ou domínio técnico
- Formalizar entregáveis de segurança como parte da definição de “done”
- Publicar um processo de “security onboarding” para fornecedores e equipas
- Criar uma **plataforma única de governação** onde sejam integradas:
  - Evidências por capítulo do manual
  - Checklists aplicados
  - Maturidade atingida por projeto
  - Justificações formais e aprovações

---

> Nos anexos e addons deste capítulo encontrarás:
> - Templates de exceções, onboarding e aprovação (`addon/`)
> - Mapeamento de maturidade e boas práticas (`canon/10-maturidade.md`)
> - Aplicação no ciclo de vida com user stories (`canon/15-aplicacao-lifecycle.md`)
> - Checklist de validação de governação e contratação (`canon/20-checklist-revisao.md`)
> - Recomendações avançadas e políticas específicas (`canon/30`, `60`)

---
