---
id: aplicacao-lifecycle
title: Aplicação de Gestão de Dependências no Ciclo de Vida
description: Integração prática das práticas de dependências, SBOM e SCA ao longo do ciclo de desenvolvimento
tags: [lifecycle, dependencias, sbom, sca, dsomm, supply-chain, cicd]
sidebar_position: 15

---

# 📦 Aplicação de Gestão de Dependências ao Longo do Ciclo de Vida {dependencias-sbom-sca:canon:aplicacao-lifecycle}

Este anexo define **como aplicar de forma sistemática as práticas de gestão de dependências, SBOM e SCA** ao longo do ciclo de desenvolvimento, integrando-as com processos ágeis, pipelines CI/CD, validações de segurança e decisões de go-live.

Inclui artefactos reutilizáveis, user stories e ações esperadas por papel, com variação proporcional por nível de risco da aplicação (L1–L3).

---

## 🧭 Quando aplicar práticas de dependências, SBOM e SCA {dependencias-sbom-sca:canon:aplicacao-lifecycle#quando_aplicar_praticas_de_dependencias_sbom_e_sca}

| Fase / Evento                        | Ação esperada                                                                 | Artefacto principal                    |
| ------------------------------------ | ----------------------------------------------------------------------------- | -------------------------------------- |
| 🚧 Início de projeto                 | Definir bibliotecas permitidas, fontes confiáveis e política de uso           | `política-bibliotecas.md`              |
| 🧱 Desenvolvimento de funcionalidade | Validar novas dependências com base em critérios de governaça                 | Comentário no PR + justificativo       |
| 🔄 Atualizações de pacotes           | Verificar changelog, executar SCA e documentar impacto                        | Commit + issue + resultado do scan     |
| 🛠 Build de aplicação                | Gerar automaticamente SBOM e executar scanner de vulnerabilidades             | Artefacto `.sbom.json` + relatório SCA |
| 🚀 Release / go-live                 | Verificar findings pendentes, exceções justificadas, assinatura de artefactos | Checklist de release                   |
| 🔁 Ciclos regulares (ex: sprint)     | Atualizar libs com TTL vencido, rever findings aceites                        | Pull request + validação AppSec        |
| ⚠️ CVE divulgado                     | Validar impacto, aplicar fix ou registar exceção com validade                 | `excecoes.yaml` + issue                |

---

## 👥 Quem executa cada ação {dependencias-sbom-sca:canon:aplicacao-lifecycle#quem_executa_cada_acao}

| Papel / Função       | Responsabilidades                                            |
| -------------------- | ------------------------------------------------------------ |
| Dev / Dev Lead       | Introdução e justificação de dependências                    |
| AppSec / Segurança   | Validação de findings, exceções, políticas e rastreabilidade |
| CI/CD / DevOps       | Geração de SBOM, scanners, controlo de origem de pacotes     |
| Produto / Gestão     | Aprovação de exceções com base em impacto e risco residual   |
| QA / Release Manager | Validação de critérios de segurança antes de entrega         |

---

## 🧾 User Stories e Cartões Reutilizáveis {dependencias-sbom-sca:canon:aplicacao-lifecycle#user_stories_e_cartoes_reutilizaveis}

Estes exemplos podem ser usados em boards de produto, revisões técnicas ou pipelines para reforçar a adoção das práticas prescritas.

### 🟦 Story: Inclusão de nova biblioteca {dependencias-sbom-sca:canon:aplicacao-lifecycle#story_inclusao_de_nova_biblioteca}

> Como developer, quero justificar a inclusão de uma nova biblioteca, para que a equipa de segurança possa validar a sua adequação.

**Checklist:**

* [ ] Nome, versão, origem e função da biblioteca documentados
* [ ] Verificação de CVEs ativos
* [ ] Licença compatível com o projeto
* [ ] Pull Request com comentário justificativo

### 🟦 Story: Geração de SBOM no pipeline {dependencias-sbom-sca:canon:aplicacao-lifecycle#story_geracao_de_sbom_no_pipeline}

> Como DevOps, quero garantir que o pipeline gera um SBOM completo por build, para que todos os artefactos possam ser rastreados.

**Checklist:**

* [ ] SBOM gerado automaticamente (ex: Syft, CycloneDX)
* [ ] Guardado como artefacto versionado
* [ ] Inclui dependências transitivas
* [ ] Validado por scanner SCA

### 🟦 Story: Aprovação de exceção a vulnerabilidade {dependencias-sbom-sca:canon:aplicacao-lifecycle#story_aprovacao_de_excecao_a_vulnerabilidade}

> Como AppSec, quero aprovar ou rejeitar exceções a CVEs com base em impacto, para garantir que há rastreabilidade e validade definida.

**Checklist:**

* [ ] CVE claramente identificado
* [ ] Justificação técnica documentada
* [ ] Prazo de validade definido
* [ ] Controlo compensatório (se aplicável)

### 🟦 Story: Atualização periódica de dependências {dependencias-sbom-sca:canon:aplicacao-lifecycle#story_atualizacao_periodica_de_dependencias}

> Como developer, quero saber quais bibliotecas estão desatualizadas, para incluir a atualização na sprint.

**Checklist:**

* [ ] Identificação automática por bot ou script
* [ ] Registo no backlog (issue)
* [ ] Atualização validada por CI + SCA

### 🟦 Story: Controlo de origem de pacotes {dependencias-sbom-sca:canon:aplicacao-lifecycle#story_controlo_de_origem_de_pacotes}

> Como DevOps, quero garantir que apenas repositórios autorizados são usados no build, para evitar código de origem não verificada.

**Checklist:**

* [ ] Uso de proxy interno ou mirror privado
* [ ] Acesso a repositórios externos limitado
* [ ] Política definida e aplicada em `.npmrc`, `settings.xml`, etc.

### 🟦 Story: Validação de findings antes da release {dependencias-sbom-sca:canon:aplicacao-lifecycle#story_validacao_de_findings_antes_da_release}

> Como QA, quero garantir que todos os findings críticos estão justificados antes da entrega, para validar que o software pode ir para produção.

**Checklist:**

* [ ] Verificação automática no pipeline
* [ ] Exceções rastreadas e aprovadas
* [ ] Checklist de release preenchido

---

### 🟦 Story: Integração de SCA com bloqueio automático {dependencias-sbom-sca:canon:aplicacao-lifecycle#story_integracao_de_sca_com_bloqueio_automatico}

> Como engenheiro de CI/CD, quero que o pipeline bloqueie builds com vulnerabilidades não resolvidas, para impedir deploys com risco não aceite.

**Checklist:**

* [ ] Scanner configurado para falhar em findings críticos
* [ ] Política de severidade documentada
* [ ] Exceptions referenciadas e justificadas
* [ ] Resultado visível no PR ou pipeline

### 🟦 Story: Rastreabilidade entre CVE, componente e release {dependencias-sbom-sca:canon:aplicacao-lifecycle#story_rastreabilidade_entre_cve_componente_e_release}

> Como analista de segurança, quero consultar o SBOM e saber quais CVEs ainda estão em aberto, para priorizar mitigação e acionar resposta.

**Checklist:**

* [ ] CVE ligado a componente via SBOM
* [ ] Finding associado a artefacto ou versão
* [ ] Tarefa ou issue de correção criada
* [ ] Estado (corrigido, aceite, mitigado) definido e justificado

### 🟦 Story: Revalidação periódica de exceções vencidas {dependencias-sbom-sca:canon:aplicacao-lifecycle#story_revalidacao_periodica_de_excecoes_vencidas}

> Como AppSec, quero verificar se findings aceites estão dentro do prazo de reavaliação, para forçar atualização ou mitigação quando necessário.

**Checklist:**

* [ ] Exceções com validade definida (ex: 90 dias)
* [ ] Dashboard ou lista de exceções por expirar
* [ ] Revisão forçada por sprint ou release
* [ ] Documentação de decisão (manter, corrigir, mitigar)

## 📄 Templates e artefactos esperados {dependencias-sbom-sca:canon:aplicacao-lifecycle#templates_e_artefactos_esperados}

| Artefacto                | Formato recomendando   | Onde guardar / referenciar                |
| ------------------------ | ---------------------- | ----------------------------------------- |
| SBOM                     | CycloneDX JSON / SPDX  | Artefacto da build + repositório `.sbom/` |
| Relatório SCA            | JSON / SARIF / HTML    | Pipeline + issue/tarefa associada         |
| Ficheiro de exceções     | `excecoes.yaml`        | Diretório `security/` no repo             |
| Política de dependências | Markdown / Confluence  | Diretório `docs/` ou wiki de equipa       |
| Checklist de release     | Markdown ou formulário | Pull request final / repositório          |


---

## ⚖️ Aplicação proporcional por nível de risco (L1–L2–L3) {dependencias-sbom-sca:canon:aplicacao-lifecycle#aplicacao_proporcional_por_nivel_de_risco_l1l2l3}

| Prática                   | L1 (baixo risco)              | L2 (risco moderado)           | L3 (risco elevado)                            |
| ------------------------- | ----------------------------- | ----------------------------- | --------------------------------------------- |
| SBOM                      | Opcional ou parcial           | Gerado por build              | Obrigatório e versionado                      |
| SCA                       | `npm audit`, `pip-audit`      | Scanner com política definida | Scanner integrado com bloqueio por severidade |
| Frequência de atualização | Mensal                        | Quinzenal                     | Semanal + bots automatizados                  |
| Justificação de exceções  | Informal (comentário no PR)   | Issue documentado com análise | Formato estruturado + prazo + revalidação     |
| Controlo de origem        | Repositório público permitido | Proxy interno                 | Repositório privado com fallback validado     |

---

## ✅ Recomendações finais {dependencias-sbom-sca:canon:aplicacao-lifecycle#recomendacoes_finais}

* As equipas devem integrar estas práticas **de forma nativa no seu fluxo de trabalho** (ex: CI/CD, backlog, releases).
* Os artefactos devem ser **versionados e rastreáveis**, mesmo quando gerados automaticamente.
* A **adoção progressiva** destas práticas deve acompanhar a maturidade da organização e o nível de risco dos produtos.


> 🔁 A gestão de dependências e SBOM não é uma atividade pontual — é **contínua e estratégica**, com impacto direto na segurança, resiliência e capacidade de resposta a incidentes.
