---
id: intro
title: Infraestrutura como Código (IaC)
description: Práticas de segurança para definição, validação e gestão de infraestrutura como código
tags: [infraestrutura, iac, terraform, segurança, automatização, DSOMM, SAMM, SLSA, SSDF]
---
import Badge from '@site/src/components/Badge';

<div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1rem' }}>
  <Badge color="warning">Capítulo Basilar</Badge>
  <Badge color="info">SAMM: 2 / 3</Badge>
  <Badge color="info">BSIMM: CMVM1.1, CMVM2.3, CP1.2</Badge>
  <Badge color="info">SSDF: PW.5, CM.1, PS.2, PW.6</Badge>
  <Badge color="info">SLSA: Nível 2 / 4</Badge>
  <Badge color="info">DSOMM: 3 / 4 (média)</Badge>
  <a href="./canon/10-maturidade.md" style={{ marginLeft: 'auto', fontSize: '0.9rem' }}>📄 Ver análise de maturidade</a>
</div>


# Segurança em Infraestrutura como Código (IaC) {iac-infraestrutura:intro}

## 🧭 1. O que cobre tecnicamente {iac-infraestrutura:intro#1_o_que_cobre_tecnicamente}

Este capítulo aborda práticas seguras para definição e gestão de infraestrutura através de código, incluindo:

- Templates e scripts de provisionamento (Terraform, Pulumi, CloudFormation, etc.)
- Automatização de ambientes (ex: via pipelines CI/CD)
- Validação e controlo de configuração
- Deteção de más práticas, permissões excessivas, exposição não intencional
- Integração com políticas organizacionais e enforcement automatizado

---

## 🧪 2. Prescrição prática: o quê, quem, como, quando, porquê e para quê {iac-infraestrutura:intro#2_prescricao_pratica_o_que_quem_como_quando_porque_e_para_que}

### 📌 O que deve ser feito {iac-infraestrutura:intro#o_que_deve_ser_feito}

1. Utilizar ferramentas declarativas e reprodutíveis para provisionamento (ex: Terraform)
2. Definir controlos de segurança como código (ex: policies, tagging, redes privadas)
3. Automatizar a validação e o scanning de segurança do IaC antes do deploy
4. Garantir versionamento, rastreabilidade e segregação de ambientes
5. Reforçar princípios de mínimo privilégio e *least exposure* na configuração

### ⚙️ Como deve ser feito {iac-infraestrutura:intro#como_deve_ser_feito}

- Scanners como `tfsec`, `checkov`, `kics`, `terrascan`
- Policies com `OPA`, `Sentinel`, `Conftest`
- Integração com pipelines CI/CD para validação obrigatória
- Módulos reutilizáveis com segurança embebida
- Uso de ferramentas como `infracost` para sensibilizar sobre impacto

### 📆 Quando aplicar {iac-infraestrutura:intro#quando_aplicar}

- Sempre que houver alterações em scripts/templates IaC
- Durante code review e pull requests de infra
- Antes de execução de pipelines que afetem ambientes reais

### 👥 Quem está envolvido e como {iac-infraestrutura:intro#quem_esta_envolvido_e_como}

| Papel/Função      | Contributo principal                                  |
|-------------------|-------------------------------------------------------|
| DevOps/Infra      | Escrita e revisão de templates IaC                    |
| Segurança         | Definição de políticas e scanners obrigatórios        |
| Arquitetura       | Validação técnica de padrões de infraestrutura        |
| Equipa de Produto | Aprovação de ambientes e riscos associados            |

### 🎯 Porquê / Para quê {iac-infraestrutura:intro#porque__para_que}

- Reduzir risco de exposição por erro de configuração
- Garantir consistência e rastreabilidade na definição de infraestruturas
- Suportar auditorias e conformidade com requisitos regulatórios
- Prevenir configuração drift ou ambientes inseguros

---

## ⚠️ 3. Caveats ou limitações da prescrição {iac-infraestrutura:intro#3_caveats_ou_limitacoes_da_prescricao}

- Nem todos os recursos podem ser definidos via IaC (limitações técnicas ou políticas)
- Ferramentas de validação podem gerar falsos positivos ou ser facilmente contornadas
- Exige cultura de versionamento e revisão de código para ser eficaz

---

## 💡 4. Exemplos de aplicação {iac-infraestrutura:intro#4_exemplos_de_aplicacao}

- Rejeição automática de PRs com `public = true` em módulos Terraform
- Enforcement de tagging obrigatório com `OPA` para recursos cloud
- Uso de `tfsec` em todos os pipelines com falha em caso de severidade alta
- Repositório central de módulos certificados com padrões seguros

---

## 🧰 5. O que pode ser feito mais (e porquê) {iac-infraestrutura:intro#5_o_que_pode_ser_feito_mais_e_porque}

- Criar biblioteca interna de módulos reutilizáveis com práticas seguras
- Desenvolver regras de OPA específicas à organização
- Integrar custos de não conformidade (ex: penalização de uso de recursos públicos)
- Criar dashboard com cobertura e compliance de templates IaC

---

> 🔗 Vê também os addons deste capítulo:
> - `10-maturidade.md`: alinhamento com frameworks
> - `15-aplicacao-lifecycle.md`: como aplicar ao longo do SDLC
> - `20-checklist-revisao.md`: verificação prática da adoção

