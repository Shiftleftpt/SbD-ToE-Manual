---
id: intro
title: Introdução — Monitorização e Operações
sidebar_position: 0
description: Práticas de logging, deteção e resposta a eventos operacionais aplicadas ao ciclo de vida de software.
tags: [monitorizacao, deteccao, resposta, telemetria, logging, operacoes]
---
import Badge from '@site/src/components/Badge';

<div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1rem' }}>
  <Badge color="warning">Capítulo Basilar</Badge>
  <Badge color="info">SAMM: 3 / 3</Badge>
  <Badge color="info">BSIMM: TDI1.1, TDI2.2, IR1.4</Badge>
  <Badge color="info">SSDF: DE.1.2, RV.1.2, RV.1.3</Badge>
  <Badge color="info">SLSA: Nível 2 / 4</Badge>
  <Badge color="info">DSOMM: 5 / 5 (Operations)</Badge>
  <a href="./canon/10-maturidade.md" style={{ marginLeft: 'auto', fontSize: '0.9rem' }}>📄 Ver análise de maturidade</a>
</div>


:::caution Capítulo Basilar

Este capítulo é considerado **basilar** no modelo SbD-ToE. A sua não aplicação compromete a visibilidade, a deteção precoce de falhas e a capacidade de resposta a incidentes.

:::

# 📊 Monitorização e Operações de Segurança {monitorizacao-operacoes:intro}

## 🧠 Enquadramento e Rationale {monitorizacao-operacoes:intro#enquadramento_e_rationale}

A capacidade de **detetar e reagir a eventos de segurança e operação** é essencial para uma postura segura. Este capítulo prescreve práticas para garantir:

* Logging estruturado e persistente
* Centralização de logs e integração com SIEMs
* Geração e tuning de alertas significativos
* Correlação entre fontes (aplicação, infra, CI/CD)
* Integração com processos de resposta a incidentes (IRP)
* Medidas operacionais como MTTD/MTTR e simulação de triggers

As práticas aqui descritas respondem diretamente a frameworks como **SAMM**, **BSIMM**, **SSDF**, **SLSA** e **DSOMM**, sendo consideradas fundamentais para garantir:

- **Visibilidade operacional contínua**;
- **Resposta estruturada a incidentes**;
- **Melhoria contínua suportada por métricas reais**;
- **Alimentação de ciclos de feedback e modelação de ameaças**.

A aplicação é feita de forma **proporcional ao risco da aplicação** (L1 a L3), com base na matriz de controlos definida neste capítulo.

---

## 1. 🛏️ O que cobre tecnicamente {monitorizacao-operacoes:intro#1__o_que_cobre_tecnicamente}

Recolha, análise, correlação e resposta a eventos relevantes para a segurança e operação, incluindo:

* Logging técnico e de segurança
* Alertas automáticos e deteção de anomalias
* Correlação e perfil comportamental
* Integração com SIEMs e IRP
* Simulação de triggers e medição de MTTD/MTTR

---

## 2. 🧪 Prescrição prática: o quê, quem, como, quando, porquê e para quê {monitorizacao-operacoes:intro#2__prescricao_pratica_o_que_quem_como_quando_porque_e_para_que}

### 📌 O que deve ser feito {monitorizacao-operacoes:intro#o_que_deve_ser_feito}

1. Logging estruturado de eventos críticos (autenticação, erros, alterações)
2. Envio seguro e persistente de logs para sistema centralizado
3. Configuração de alertas automáticos para eventos relevantes
4. Correlação entre fontes distintas (app, infra, pipeline)
5. Integração com IRP e sistema de resposta
6. Simulação de triggers e medição de tempos de resposta (MTTD/MTTR)

### ⚙️ Como deve ser feito {monitorizacao-operacoes:intro#como_deve_ser_feito}

* Usar formatos estruturados (ex: JSON ECS, CEF)
* Estabelecer tempos de retenção ≥30 dias, com TLS e ACL
* Utilizar sistemas como Elastic, Splunk, Sentinel, Loki, etc.
* Definir alertas com base em severidade, volume e comportamento
* Correlacionar eventos entre fontes (logs, audit, execução)
* Avaliar cobertura: % logs integrados, alertas testados, MTTD real

### 🗓️ Quando aplicar {monitorizacao-operacoes:intro#quando_aplicar}

* Desde o design: definir eventos a registar e responsáveis
* Antes de go-live: verificar cobertura obrigatória por risco (ver abaixo)
* Em operação: monitorizar, simular alertas e ajustar continuamente

### 👥 Quem está envolvido e como {monitorizacao-operacoes:intro#quem_esta_envolvido_e_como}

| Papel/Função            | Contributo principal                                        |
|-------------------------|-------------------------------------------------------------|
| Desenvolvimento         | Implementa eventos, integra com sistema de logging          |
| DevOps / Infraestrutura | Garante encaminhamento, retenção e disponibilidade dos logs |
| Segurança / AppSec      | Define eventos críticos, alerta, correlação                 |
| Resposta a Incidentes   | Consome logs e alertas, atua em investigação e contenção    |
| GRC / Auditoria         | Valida existência, rastreabilidade e conformidade normativa |

> ✅ Todos os eventos e alertas devem ser versionados, testados e auditáveis.

### 🌟 Porquê / Para quê {monitorizacao-operacoes:intro#porque__para_que}

* Deteção precoce de abuso, falhas e execução invulgar
* Reação rápida a incidentes (IR)
* Evidência de controlo efetivo
* Cumprimento de normas (ex: ISO 27001, NIS2, PCI-DSS)
* Alimentar melhoria contínua com dados reais

---

## 3. 🔹 Aplicar por Nível de Risco {monitorizacao-operacoes:intro#3__aplicar_por_nivel_de_risco}

As práticas prescritas são aplicadas de forma **proporcional à criticidade da aplicação (L1 a L3)**. A tabela seguinte define os controlos mínimos obrigatórios por nível:

| Controlo / Requisito                           |  L1 |  L2 |  L3 |
|-----------------------------------------------|:---:|:---:|:---:|
| Logging estruturado e persistente              |  ✔️ |  ✔️ |  ✔️ |
| Eventos críticos definidos (login, erro, etc.) |  ✔️ |  ✔️ |  ✔️ |
| Retenção mínima (≥ 30 dias)                    |     |  ✔️ |  ✔️ |
| Logs enviados para sistema centralizado (SIEM) |     |  ✔️ |  ✔️ |
| Alertas automáticos configurados               |     |  ✔️ |  ✔️ |
| Simulações de trigger testadas                 |     |  ✔️ |  ✔️ |
| Correlação entre fontes                        |     |     |  ✔️ |
| Deteção comportamental / perfis adaptativos    |     |     |  ✔️ |
| Integração com resposta a incidentes (IRP)     |     |  ✔️ |  ✔️ |
| Métricas de MTTD / MTTR monitorizadas          |     |     |  ✔️ |

> 🔹 Aplicações L1 com exposição externa ou dados sensíveis devem cumprir L2 ou L3.

> 🔹 Estes requisitos devem ser incluídos em critérios de aceitação e "Definition of Done".

---

## 🚨 Aviso Final {monitorizacao-operacoes:intro#aviso_final}

A ausência de logging, correlação e resposta estruturada impede a deteção eficaz de ataques ou falhas. Este capítulo é essencial para garantir que os restantes controlos são visíveis, auditáveis e eficazes.

> ⚠️ Monitorizar é controlar. Sem visibilidade não há segurança operacional.
