---
id: aplicacao-lifecycle
title: Aplicação no Ciclo de Vida — Infraestrutura como Código (IaC)
sidebar_position: 15
description: Integração prática das práticas de segurança IaC ao longo do ciclo de vida, com user stories, tarefas e modelos de backlog.
tags: [ciclo de vida, aplicação prática, iac, infraestrutura como código, user stories]
---



# 🚀 Aplicação das Práticas de Segurança IaC no Ciclo de Vida {iac-infraestrutura:canon:aplicacao-lifecycle}

Este anexo descreve **quando, quem e como aplicar as práticas prescritas no Capítulo 08 — Infraestrutura como Código (IaC)** ao longo do ciclo de vida de um projeto de desenvolvimento ou manutenção de infraestrutura.

Cada prática definida no capítulo é associada a **user stories, tarefas e cartões reutilizáveis**, permitindo a sua integração direta em backlog, boards ou processos formais de aprovação.

> 💡 A seleção e parametrização dos requisitos `IAC-XXX` deve considerar os resultados do *threat modeling* do projeto (ver Capítulo 03), especialmente para práticas como segregação de ambientes, controlo de módulos e enforcement automatizado.

---

## 1. Momentos de aplicação no SDLC {iac-infraestrutura:canon:aplicacao-lifecycle#1_momentos_de_aplicacao_no_sdlc}

| Fase do ciclo de vida     | Momento de aplicação                                 | Prática aplicada          | Quem aplica                       |
| ------------------------- | ---------------------------------------------------- | ------------------------- | --------------------------------- |
| Início de projeto IaC     | Criação do repositório e definição da stack          | IAC-001, IAC-002, IAC-006 | Arquiteto, DevOps                 |
| Configuração de ambientes | Definição e segregação de ambientes                  | IAC-002, IAC-008          | DevOps, Infra, SecOps             |
| Pipeline CI/CD            | Definição e revisão de pipeline                      | IAC-003, IAC-009, IAC-010 | DevOps, AppSec                    |
| Adoção de módulos         | Importação de novos módulos ou bibliotecas           | IAC-004, IAC-006          | Infra, DevOps                     |
| Alterações de infra       | Cada PR com alteração de recursos IaC                | IAC-005, IAC-007          | Equipa IaC, Reviewer de segurança |
| Validação antes do apply  | Aprovação antes de alteração em ambientes produtivos | IAC-007, IAC-009, IAC-010 | Responsável técnico, AppSec       |

---

## 2. User stories por requisito (exaustivo) {iac-infraestrutura:canon:aplicacao-lifecycle#2_user_stories_por_requisito_exaustivo}

Cada requisito `IAC-XXX` tem uma **user story reutilizável**, com critérios de aceitação alinhados com os controlos definidos no capítulo.

### 🧩 IAC-001 — Backend remoto com locking {iac-infraestrutura:canon:aplicacao-lifecycle#iac_001__backend_remoto_com_locking}

**User Story:**
Como responsável pelo repositório IaC, quero configurar o backend remoto com locking, para garantir que o estado da infraestrutura é consistente e protegido contra concorrência.

**Critérios de aceitação:**

* Configuração de backend com locking (`S3`, `DynamoDB`, `KMS`)
* Teste de concorrência documentado
* Validação incluída no CI/CD

### 🧩 IAC-002 — Segregação e versionamento de ambientes {iac-infraestrutura:canon:aplicacao-lifecycle#iac_002__segregacao_e_versionamento_de_ambientes}

**User Story:**
Como engenheiro de DevOps, quero definir ambientes em diretórios separados e com versionamento próprio, para garantir isolamento, auditabilidade e rollback.

**Critérios de aceitação:**

* Diretórios por ambiente (`dev/`, `prod/`)
* Branches dedicadas se necessário
* Tags/releases para alterações críticas

### 🧩 IAC-003 — Validações automáticas {iac-infraestrutura:canon:aplicacao-lifecycle#iac_003__validacoes_automaticas}

**User Story:**
Como membro da equipa IaC, quero que todas as alterações passem por validações automáticas (lint, policy, segurança), para evitar erros humanos ou más práticas.

**Critérios de aceitação:**

* Execução obrigatória de `tfsec`, `tflint`, OPA, etc.
* Build falha se não conformidade
* Logs arquivados por ambiente

### 🧩 IAC-004 — Origem confiável de módulos {iac-infraestrutura:canon:aplicacao-lifecycle#iac_004__origem_confiavel_de_modulos}

**User Story:**
Como responsável por segurança, quero que apenas módulos verificados e confiáveis sejam utilizados, para evitar inclusão de código malicioso ou obsoleto.

**Critérios de aceitação:**

* Módulos pinados por versão
* Origem interna ou com validação manual
* Evidência documentada em PR

### 🧩 IAC-005 — Histórico de alterações com tagging {iac-infraestrutura:canon:aplicacao-lifecycle#iac_005__historico_de_alteracoes_com_tagging}

**User Story:**
Como engenheiro de release, quero garantir que todas as alterações a infraestruturas estejam devidamente versionadas e com histórico auditável.

**Critérios de aceitação:**

* Uso de Git com tags semânticas
* Releases formais documentadas
* Relatório de mudanças por release

### 🧩 IAC-006 — Convenções de naming e diretórios {iac-infraestrutura:canon:aplicacao-lifecycle#iac_006__convencoes_de_naming_e_diretorios}

**User Story:**
Como membro da equipa de infraestrutura, quero aplicar convenções padronizadas no naming e estrutura dos diretórios, para garantir legibilidade, automação e validação fácil.

**Critérios de aceitação:**

* Convenções documentadas (`naming.md`)
* Linter ou validação incluída no pipeline

### 🧩 IAC-007 — `Plan` revisto antes de `apply` {iac-infraestrutura:canon:aplicacao-lifecycle#iac_007__plan_revisto_antes_de_apply}

**User Story:**
Como responsável pela aprovação, quero rever o plano de alterações (`terraform plan`) antes da sua aplicação, para garantir que os impactos estão claros e validados.

**Critérios de aceitação:**

* Output de `plan` anexado ao PR
* Aprovado por reviewer técnico
* Aplicação bloqueada se não aprovado

### 🧩 IAC-008 — Rastreabilidade ficheiros-recursos {iac-infraestrutura:canon:aplicacao-lifecycle#iac_008__rastreabilidade_ficheiros_recursos}

**User Story:**
Como auditor de segurança, quero garantir que cada ficheiro do projeto afeta recursos específicos e bem identificados, para facilitar accountability e auditoria.

**Critérios de aceitação:**

* Mapeamento ficheiro → recurso → ambiente
* Documentação incluída ou gerada automaticamente

### 🧩 IAC-009 — Enforcement automático de políticas {iac-infraestrutura:canon:aplicacao-lifecycle#iac_009__enforcement_automatico_de_politicas}

**User Story:**
Como responsável de segurança, quero que o pipeline CI/CD aplique políticas de segurança obrigatórias automaticamente, para evitar violações por erro humano.

**Critérios de aceitação:**

* Políticas OPA, Sentinel ou Rego ativas
* Build falha se não conforme
* Log de enforcement arquivado

### 🧩 IAC-010 — Versionamento e hash de artefactos {iac-infraestrutura:canon:aplicacao-lifecycle#iac_010__versionamento_e_hash_de_artefactos}

**User Story:**
Como engenheiro de release, quero que todos os artefactos gerados (plan, apply, manifests) sejam versionados e assinados, para garantir rastreabilidade e integridade.

**Critérios de aceitação:**

* Artefactos versionados com hash
* Assinatura automatizada ou manual
* Disponível por release ou ambiente

---


## 3. Recomendações de estrutura de backlog {iac-infraestrutura:canon:aplicacao-lifecycle#3_recomendacoes_de_estrutura_de_backlog}

| Tipo de cartão                     | Quando criar                             | Ligação ao capítulo         |
| ---------------------------------- | ---------------------------------------- | --------------------------- |
| `Inicializar projeto IaC`          | Criação de repositório e pipeline        | IAC-001 a IAC-003           |
| `Definir ambientes`                | Antes da primeira aplicação a cada stack | IAC-002                     |
| `Configurar validações`            | Setup inicial de CI/CD                   | IAC-003, IAC-009            |
| `Auditar módulos externos`         | Adoção de novo módulo ou dependência     | IAC-004                     |
| `Revisar plano de alterações`      | Antes do merge ou do `apply`             | IAC-007                     |
| `Aplicar tagging e versionamento`  | A cada release ou milestone              | IAC-005, IAC-010            |
| `Revisar estrutura do repositório` | Periodicamente ou após reestruturação    | IAC-006, IAC-008            |
| `Rever exceções ativas`           | Periodicamente ou por auditoria          | IAC-009, addon/09           |

---

## 4. Sugestão de repositório de exemplos {iac-infraestrutura:canon:aplicacao-lifecycle#4_sugestao_de_repositorio_de_exemplos}

* Diretório `templates/` no repositório IaC:
  * `iac-story-iac001-backend.md`
  * `iac-task-iac007-review-plan.md`
  * `iac-checklist-release.md`
* Wiki técnica com critérios por requisito (`REQ` e `IAC`)
* Dashboards de validação automatizada por ambiente

> 🧪 Testes avançados como `terratest`, `opa test` ou deteção de drift devem ser integrados quando definidos pelas equipas de segurança como prática padrão (ver `30-recomendacoes-avancadas.md`).

---

> 📌 Este ficheiro deve ser mantido atualizado à medida que forem introduzidas novas práticas ou requisitos técnicos no Capítulo 08 — Infraestrutura como Código
