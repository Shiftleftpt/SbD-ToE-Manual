---

id: aplicacao-lifecycle
title: Aplicação de Requisitos de Segurança no Ciclo de Vida
description: Integração das práticas de requisitos ao longo das fases do ciclo de desenvolvimento
tags: [tipo:aplicacao, execucao, ciclo de vida, requisitos, validação, rastreabilidade, exceções]
sidebar_position: 15
---

<!--template: sbdtoe-usage -->

# 🛠️ Aplicação de Requisitos de Segurança no Ciclo de Vida {requisitos-seguranca:aplicacao-lifecycle}

Este anexo prescreve **como aplicar sistematicamente os requisitos definidos no Capítulo 2** ao longo do ciclo de desenvolvimento, garantindo rastreabilidade, proporcionalidade ao risco e validação contínua.

Inclui modelos reutilizáveis de user stories, ações por papel, artefactos esperados e quadros de aplicação por nível de criticidade (L1–L3).

---

## 📅 Quando aplicar os requisitos de segurança {requisitos-seguranca:aplicacao-lifecycle#quando_aplicar_os_requisitos_de_seguranca}

| Fase / Evento                   | Ação esperada                                                 | Artefacto principal              |
| ------------------------------- | ------------------------------------------------------------- | -------------------------------- |
| Início de projeto               | Seleção proporcional de requisitos com base na criticidade    | `matriz-controlos-por-risco.md`  |
| Grooming / Planeamento          | Transformar requisitos em cartões rastreáveis                 | Backlog (cards + tags `SEC-...`) |
| Nova funcionalidade / refactor  | Revalidar requisitos aplicáveis à alteração                   | Tarefa técnica / story revisada  |
| Integração ou exposição externa | Rever requisitos de autenticação, logging, controlo de acesso | Issue ou checklist de integração |
| Sprint review ou testes         | Verificar critérios de aceitação de segurança                 | Critérios + testes associados    |
| Preparação para go-live         | Validar requisitos aplicados, exceções aprovadas, coverage    | Checklist de release             |

---

## 👥 Quem faz o quê {requisitos-seguranca:aplicacao-lifecycle#quem_faz_o_que}

| Papel / Função          | Responsabilidades-chave                                      |
| ----------------------- | ------------------------------------------------------------ |
| Product Owner           | Selecionar requisitos conforme risco e garantir visibilidade |
| Developer               | Implementar requisitos e rastrear via tags                   |
| QA / Test Engineer      | Garantir critérios de aceitação e cobertura de testes        |
| AppSec / Segurança      | Validar requisitos aplicados e aprovar exceções              |
| Arquitetura / Tech Lead | Rever requisitos em refactors ou integrações                 |

---

## 📝 User Stories e Cartões Reutilizáveis {requisitos-seguranca:aplicacao-lifecycle#user_stories_e_cartoes_reutilizaveis}

<!--userstory:start-->

### Story: Seleção de requisitos com base na criticidade {requisitos-seguranca:aplicacao-lifecycle#story_selecao_de_requisitos_com_base_na_criticidade}

Como Product Owner, quero selecionar os requisitos aplicáveis ao projeto, para garantir que a segurança é proporcional ao nível de risco.

**Definition of Done:**

* [ ] Classificação de criticidade (L1–L3) atribuída
* [ ] Matriz de aplicação usada (`SEC-Lx-...`)
* [ ] Requisitos marcados no backlog

> Suporta rastreabilidade segundo a matriz definida neste capítulo.

<!--userstory:end-->

<!--userstory:start-->

### Story: Aplicar requisito de logging seguro (ex: T03) {requisitos-seguranca:aplicacao-lifecycle#story_aplicar_requisito_de_logging_seguro_ex_t03}

Como developer, quero garantir que todos os acessos críticos são registados, para que haja visibilidade e rastreabilidade.

**Definition of Done:**

* [ ] Campos essenciais definidos (ex: ID user, IP, ação)
* [ ] Logs estruturados com formato comum
* [ ] Retenção e proteção dos logs documentadas

> Baseado nos temas de requisitos T03.

<!--userstory:end-->

<!--userstory:start-->

### Story: Submeter exceção a requisito {requisitos-seguranca:aplicacao-lifecycle#story_submeter_excecao_a_requisito}

Como developer, quero registar uma exceção a um requisito não aplicável, para que a decisão seja rastreável e validada.

**Definition of Done:**

* [ ] Justificação documentada
* [ ] Risco residual avaliado
* [ ] Prazo de validade definido
* [ ] Aprovação de AppSec/documentação de decisão

> Deve ser rastreável segundo o processo definido na secção de gestão de exceções.

<!--userstory:end-->

<!--userstory:start-->

### Story: Garantir rastreabilidade por tags {requisitos-seguranca:aplicacao-lifecycle#story_garantir_rastreabilidade_por_tags}

Como QA, quero garantir que todos os requisitos aplicados têm rastreabilidade no backlog, para suportar auditoria e verificação.

**Definition of Done:**

* [ ] Todos os cartões têm tag `SEC-Lx-Tyy-ZZZ`
* [ ] Referência cruzada com catálogo de requisitos
* [ ] Filtros e reports possíveis via board

> Fundamental para evidência em auditorias e revisão.

<!--userstory:end-->

<!--userstory:start-->

### Story: Rever requisitos após mudança funcional {requisitos-seguranca:aplicacao-lifecycle#story_rever_requisitos_apos_mudanca_funcional}

Como arquiteto, quero rever os requisitos aplicáveis sempre que uma integração crítica é adicionada, para garantir atualidade.

**Definition of Done:**

* [ ] Nova superfície de ataque identificada
* [ ] Requisitos relacionados atualizados
* [ ] Decisão registada (aceitação, exceção ou novo requisito)

> Recomendado após alterações estruturais.

<!--userstory:end-->

<!--userstory:start-->

### Story: Validar cobertura de testes dos requisitos {requisitos-seguranca:aplicacao-lifecycle#story_validar_cobertura_de_testes_dos_requisitos}

Como QA, quero garantir que todos os requisitos têm validação associada, para prevenir falsos positivos ou ausência de controlo.

**Definition of Done:**

* [ ] Testes automáticos ou manuais documentados
* [ ] Critérios de aceitação por requisito definidos
* [ ] Evidência de execução / verificação por sprint

> Essencial para controlar a eficácia dos requisitos.

<!--userstory:end-->

---

## 📊 Exemplo de Cartão Reutilizável {requisitos-seguranca:aplicacao-lifecycle#exemplo_de_cartao_reutilizavel}

```yaml
name: Aplicar requisito de validação de input na API
type: Security Task
risk_level: L2
linked_to: SEC-L2-API-INPUT_VALIDATION
description: Garantir que todas as operações da API validam os inputs de forma robusta.
acceptance_criteria:
  - Todas as entradas têm filtros de whitelist ou validação estrita
  - Erros não revelam informação interna
  - Validações testadas com inputs inválidos e edge cases
```

---

## ⚖️ Aplicação proporcional por nível de risco (L1–L2–L3) {requisitos-seguranca:aplicacao-lifecycle#aplicacao_proporcional_por_nivel_de_risco_l1l2l3}

| Prática                    | L1 (baixo risco)          | L2 (médio risco)                     | L3 (alto risco)                                  |
| -------------------------- | ------------------------- | ------------------------------------ | ------------------------------------------------ |
| Catálogo de requisitos     | Básico (10–15 requisitos) | Catálogo completo L2                 | Catálogo completo L3 + reforços adicionais       |
| Rastreabilidade (tags)     | Opcional                  | Obrigatória nos cartões de segurança | Todos os cartões técnicos e funcionais           |
| Exceções                   | Ad hoc                    | Documentadas e aprovadas             | Formalizadas com prazo e mitigação               |
| Validação de requisitos    | Revisão manual            | Testes associados                    | Testes + cobertura + revisão independente        |
| Reavaliação por alterações | Parcial / a pedido        | A cada funcionalidade crítica        | Sempre que há mudança de controlo ou arquitetura |

---

## 📄 Templates e artefactos esperados {requisitos-seguranca:aplicacao-lifecycle#templates_e_artefactos_esperados}

| Artefacto                       | Formato sugerido           | Onde guardar / referenciar           |
| ------------------------------- | -------------------------- | ------------------------------------ |
| Matriz de requisitos por risco  | Markdown / tabela          | Diretório `docs/` ou Wiki de produto |
| Cartões com tags `SEC-*`        | Board / GitHub / Jira      | Backlog de equipa                    |
| Justificações de exceção        | Markdown ou YAML           | Diretório `security/excecoes/`       |
| Evidência de testes / aceitação | Checklist, screenshot, log | Pull Request, pipeline ou issue      |

---

## ✅ Recomendações finais {requisitos-seguranca:aplicacao-lifecycle#recomendacoes_finais}

* A aplicação dos requisitos de segurança deve ser **nativa e visível no ciclo de vida**;
* Os cartões devem usar **tags normalizadas e rastreáveis**;
* Exceções são legítimas, mas devem ser **justificadas, temporárias e visíveis**;
* A maturidade da equipa pode ser medida pela **rastreabilidade e validação efetiva** dos requisitos.

> 🧠 Este anexo concretiza a aplicação prática dos requisitos definidos no Capítulo 2, permitindo controlo real, melhoria contínua e auditoria objetiva.
