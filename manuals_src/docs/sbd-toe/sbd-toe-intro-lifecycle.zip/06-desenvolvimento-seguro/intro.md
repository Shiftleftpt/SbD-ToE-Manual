---
id: intro
title: Desenvolvimento Seguro
description: Práticas de codificação segura, validação automatizada, rastreabilidade e gestão de exceções durante o desenvolvimento de software
tags: [desenvolvimento, segurança, codificação segura, validação, rastreabilidade, DSOMM, SAMM, SSDF, BSIMM, SLSA]
---

import Badge from '@site/src/components/Badge';

<div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1rem' }}>
  <Badge color="warning">Capítulo Basilar</Badge>
  <Badge color="info">SAMM: 2 / 3</Badge>
  <Badge color="info">BSIMM: SE2.3, SE2.4, CP1.1</Badge>
  <Badge color="info">SSDF: PS.1, PS.2, RV.1, RV.2, PO.2</Badge>
  <Badge color="info">SLSA: Nível 2 / 4</Badge>
  <Badge color="info">DSOMM: 2 / 3 (média)</Badge>
  <a href="./canon/10-maturidade.md" style={{ marginLeft: 'auto', fontSize: '0.9rem' }}>📄 Ver análise de maturidade</a>
</div>

# Desenvolvimento Seguro {desenvolvimento-seguro:intro}

## 🧭 1. O que cobre tecnicamente {desenvolvimento-seguro:intro#1_o_que_cobre_tecnicamente}

Este capítulo define as práticas necessárias para garantir **segurança aplicacional desde as fases iniciais de desenvolvimento**, cobrindo:

- Escrita de código seguro, baseada em boas práticas
- Linters e validações automáticas (locais e via CI/CD)
- Uso de ferramentas de análise de código (SAST, Semgrep)
- Gestão segura de dependências externas e internas
- Registo formal de exceções técnicas justificadas
- Revisões de código com validação objetiva e rastreável
- Anotação semântica de validações e decisões de segurança
- Uso consciente e validado de ferramentas de GenIA no processo de desenvolvimento

Estas práticas são aplicáveis a todas as linguagens e stacks técnicas e devem ser integradas no processo de desenvolvimento, revisão, release e manutenção.
---

> ⚙️ **Nota sobre ferramentas de apoio**  
> Muitas das práticas descritas neste capítulo — como linters, validações semânticas, rastreio de dependências, análise de código e tagging de segurança — são suportadas por ferramentas amplamente disponíveis, tanto open source como comerciais (ex: Semgrep, SonarQube, Snyk, Kiuwan, Checkmarx, Xygeni).  
> A adoção estruturada dessas ferramentas pode **acelerar significativamente a aplicação prática das recomendações**, desde que acompanhada por validação humana e políticas organizacionais claras.  
> Ferramentas não substituem responsabilidade técnica, mas tornam a aplicação das práticas mais eficaz, auditável e escalável.
---
> 💡 **Nota sobre IA Generativa**  
> O uso de ferramentas de IA generativa (como GitHub Copilot, ChatGPT, Claude ou semelhantes) é reconhecido neste capítulo como prática real e crescente no desenvolvimento moderno.  
> As práticas aqui descritas foram desenhadas para garantir que a sua utilização seja **validada, rastreável e auditável**, respeitando os princípios de segurança by design.  
> A aplicação de código gerado por IA sem revisão, anotação ou justificação é considerada uma falha de controlo — tal como qualquer outro código não validado.

---

## 🧪 2. Prescrição prática: o quê, quem, como, quando, porquê e para quê {desenvolvimento-seguro:intro#2_prescricao_pratica_o_que_quem_como_quando_porque_e_para_que}

### 📌 O que deve ser feito {desenvolvimento-seguro:intro#o_que_deve_ser_feito}

1. Definir guidelines internas de desenvolvimento seguro, versionadas por stack ou projeto
2. Usar linters locais e automáticos com regras mínimas obrigatórias
3. Integrar ferramentas de validação de código (ex: SAST) no pipeline
4. Validar e justificar todas as dependências adicionadas
5. Registar exceções técnicas com plano de mitigação e aprovação
6. Rastrear validações por meio de anotações padronizadas (`@sec:*`)
7. Incorporar práticas seguras no ciclo de PRs, revisões e releases
8. Utilizar ferramentas de GenIA como reforço de boas práticas, com validação técnica posterior

### 👥 Quem é responsável {desenvolvimento-seguro:intro#quem_e_responsavel}

- **Desenvolvedores**: aplicar diretamente as boas práticas descritas
- **Revisores técnicos e leads**: validar e fazer cumprir as práticas no PR
- **Equipa de segurança / AppSec**: definir critérios, exceções e validações formais
- **Equipa técnica local**: manter e atualizar as guidelines específicas da stack

> 📌 A disseminação e formalização das práticas de desenvolvimento seguro é complementada pelas ações formativas descritas no [Capítulo 13 — Formação e Cultura Técnica].

### ⏱️ Quando aplicar {desenvolvimento-seguro:intro#quando_aplicar}

- Em qualquer tarefa de escrita, refatoração, revisão ou aceitação de código
- Ao criar ou atualizar dependências, bibliotecas ou wrappers internos
- Em cada PR, commit ou release
- Sempre que há código relacionado com input, autenticação, sessão, dados sensíveis ou lógica crítica

---

## 🧮 3. Aplicação proporcional por nível de risco {desenvolvimento-seguro:intro#3_aplicacao_proporcional_por_nivel_de_risco}

| Nível de risco | Aplicação mínima exigida                                                   |
|----------------|----------------------------------------------------------------------------|
| **L1 (baixo)** | Linters obrigatórios, checklist de PR, dependências justificadas          |
| **L2 (médio)** | Validações por SAST, anotação obrigatória, exceções aprovadas             |
| **L3 (alto)**  | Revisor técnico dedicado, integração com pipeline de segurança, rastreabilidade total |

---

:::caution Capítulo Basilar

Este capítulo é essencial para garantir práticas de desenvolvimento seguras ao longo do ciclo de vida de software.  
A sua não implementação compromete a aplicação coerente das restantes práticas do modelo SbD-ToE.

:::
