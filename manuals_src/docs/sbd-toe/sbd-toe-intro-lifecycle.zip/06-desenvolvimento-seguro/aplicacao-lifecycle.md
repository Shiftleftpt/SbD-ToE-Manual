---
id: aplicacao-lifecycle
title: Aplicação de Desenvolvimento Seguro no Ciclo de Vida
description: Alinhamento entre as práticas deste capítulo e os principais frameworks de segurança
tags: [lifecycle, desenvolvimento, SAMM, BSIMM, SSDF, SLSA, DSOMM]
sidebar_position: 10
---


# 🧬 Aplicação de Desenvolvimento Seguro ao Longo do Ciclo de Vida {desenvolvimento-seguro:canon:aplicacao-lifecycle}

Este anexo define **como aplicar, de forma sistemática, as práticas de desenvolvimento seguro** descritas no Capítulo 06, ao longo do ciclo de vida da aplicação.

Inclui user stories reutilizáveis, responsabilidades por papel, integração em pipelines, e aplicação proporcional em função do risco.

> Estas práticas devem ser **integradas desde o início do projeto**, acompanhando o design, codificação, revisão, validação e release, com registo auditável.

---

## 🧭 Quando aplicar cada prática de desenvolvimento seguro {desenvolvimento-seguro:canon:aplicacao-lifecycle#quando_aplicar_cada_pratica_de_desenvolvimento_seguro}

| Fase / Evento                   | Ação esperada                                               | Artefacto principal                  |
|--------------------------------|----------------------------------------------------------------|--------------------------------------|
| ✨ Início do projeto           | Definir regras de codificação segura e critérios de validação | `SECURITY.md`, wiki, `linters.conf` |
| 🎨 Desenvolvimento ativo     | Aplicar boas práticas, linters e validadores locais          | Commits, pre-commit hooks            |
| 🔧 Pull/Merge request        | Revisão manual e automática, tags de rastreabilidade         | Comentário `@sec:`, checklist PR     |
| 📆 Sprint / Release planning  | Rever requisitos de segurança e exceções pendentes            | `excecoes.yaml`, backlogs            |
| ⚖️ Validação antes de release | Confirmar aplicação proporcional por risco                  | Checklist de release                 |
| 📊 Auditoria / Revisão interna | Validar rastreabilidade de práticas e evidências              | Logs CI/CD, `evidencias.md`          |

---

## 👥 Quem faz o quê {desenvolvimento-seguro:canon:aplicacao-lifecycle#quem_faz_o_que}

| Papel / Função     | Responsabilidades principais                                                              |
|--------------------|--------------------------------------------------------------------------------------------|
| Developer          | Aplicar boas práticas, usar linters, justificar exceções, anotar PRs com `@sec:`          |
| Tech Lead / Reviewer | Validar aplicação de regras, bloquear merges inseguros, validar evidências técnicas       |
| AppSec / Segurança | Rever exceções, definir regras, aprovar uso de GenIA, garantir validação semântica        |
| DevOps / CI/CD     | Integrar validações no pipeline, guardar logs e evidências, aplicar bloqueios estruturais |
| Gestão / Produto   | Aprovar exceções formais, alinhar backlog com requisitos de segurança                     |

---

## 📞 User Stories e Cartões Reutilizáveis {desenvolvimento-seguro:canon:aplicacao-lifecycle#user_stories_e_cartoes_reutilizaveis}

### 📅 Story: Aplicar regras de desenvolvimento seguro {desenvolvimento-seguro:canon:aplicacao-lifecycle#story_aplicar_regras_de_desenvolvimento_seguro}

> Como developer, quero saber que regras de segurança seguir na escrita de código, para evitar vulnerabilidades comuns.

**Checklist:**
- [ ] Guia `SECURITY.md` acessível e atualizado
- [ ] Linters locais ativos (pre-commit, IDE)
- [ ] Lista de boas práticas por linguagem/stack
- [ ] Proibição de padrões inseguros documentada

---

### 🔤 Story: Validar PR com requisitos de segurança {desenvolvimento-seguro:canon:aplicacao-lifecycle#story_validar_pr_com_requisitos_de_seguranca}

> Como reviewer, quero validar se o PR respeita os requisitos de segurança, para garantir que não introduz riscos.

**Checklist:**
- [ ] Presença de anotação `@sec:` ou equivalente
- [ ] Evidência de validação (linters, testes)
- [ ] Justificação de exceções (se aplicável)
- [ ] Revisão de controlo de acesso e sanitização

---

### 📊 Story: Controlar uso de IA generativa {desenvolvimento-seguro:canon:aplicacao-lifecycle#story_controlar_uso_de_ia_generativa}

> Como AppSec, quero verificar se o código gerado com IA foi validado, para evitar introdução de vulnerabilidades não rastreadas.

**Checklist:**
- [ ] Uso de tag `@sec:genia-*` ou anotação equivalente
- [ ] Revisão manual obrigatória
- [ ] Aprovação formal do uso de IA na stack
- [ ] Política de validação de GenIA definida

---

### 🔍 Story: Validar exceção antes do merge {desenvolvimento-seguro:canon:aplicacao-lifecycle#story_validar_excecao_antes_do_merge}

> Como tech lead, quero garantir que uma exceção de segurança está justificada e aprovada, antes de permitir o merge.

**Checklist:**
- [ ] Exceção registada em `excecoes.yaml`
- [ ] Justificação técnica documentada
- [ ] Prazo de validade definido e visível
- [ ] Compensação ou mitigação indicada

---

### ✅ Story: Confirmar conformidade de segurança antes da release {desenvolvimento-seguro:canon:aplicacao-lifecycle#story_confirmar_conformidade_de_seguranca_antes_da_release}

> Como tech lead ou AppSec, quero confirmar que todos os requisitos de desenvolvimento seguro foram cumpridos, antes de lançar uma nova versão.

**Checklist:**
- [ ] Checklist do Capítulo 06 validado para esta release
- [ ] Evidência de execução das validações obrigatórias por risco
- [ ] Exceções pendentes documentadas e aceites
- [ ] SBOM ou inventário de dependências atualizado

---

## 📅 Aplicação proporcional por risco {desenvolvimento-seguro:canon:aplicacao-lifecycle#aplicacao_proporcional_por_risco}

| Prática                         | L1 (baixo risco)        | L2 (médio risco)             | L3 (alto risco)                               |
|----------------------------------|--------------------------|-------------------------------|------------------------------------------------|
| Guia de boas práticas            | Recomendado informal     | Documento partilhado          | Documento aprovado e versionado               |
| Linters e checkers locais        | Opcionais                | Obrigatórios no pre-commit    | Integração em IDE + CI obrigatória            |
| Revisão de PRs                   | Apenas em features       | Revisão por pares mandatória  | Revisão por pares + reviewer AppSec           |
| Anotação de requisitos no PR     | Opcional                 | `@sec:` para requisitos críticos | `@sec:` obrigatório em todos os PRs         |
| Justificação de exceções         | Comentário no PR         | Issue documentada             | Ficheiro estruturado + owner + aprovação      |
| Validação de código gerado por GenIA | Não aplicável         | Revisão manual recomendada    | Revisão + tag obrigatória + validação AppSec  |

---

## ✅ Recomendações finais {desenvolvimento-seguro:canon:aplicacao-lifecycle#recomendacoes_finais}

- Estas práticas devem ser **integradas nativamente no ciclo de desenvolvimento**, e nos pipelines CI/CD sempre que possível.
- As evidências de aplicação (logs, tags, ficheiros, artefactos) devem ser **versionadas, acessíveis e auditáveis**.
- Ferramentas como **Semgrep, SonarQube, pre-commit hooks e GenIA com controlo semântico** são recomendadas para facilitar a adoção.

> 📌 O objetivo não é bloquear o desenvolvimento, mas sim garantir que a qualidade técnica do código incorpora, de forma natural e proporcional, os requisitos de segurança definidos pela organização.
