---
id: intro
title: Validação Contínua de Segurança
description: Estratégias e práticas para validar continuamente a segurança de aplicações através de testes automatizados, manuais e ofensivos.
tags: [testes, segurança, validação contínua, SAST, DAST, fuzzing, pentesting, DSOMM, SAMM, SSDF, BSIMM, SLSA]
sidebar_position: 0
---
import Badge from '@site/src/components/Badge';

<div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1rem' }}>
  <Badge color="warning">Capítulo Basilar</Badge>
  <Badge color="info">SAMM: 2 / 3</Badge>
  <Badge color="info">BSIMM: SFD1.2, SE1.1, T1.3, T2.4, SE3.5</Badge>
  <Badge color="info">SSDF: RV.1, RV.3, RV.6, PS.2</Badge>
  <Badge color="info">SLSA: Nível 2 / 4</Badge>
  <Badge color="info">DSOMM: 2 / 3 (Testing, Dev)</Badge>
  <a href="./canon/10-maturidade.md" style={{ marginLeft: 'auto', fontSize: '0.9rem' }}>📄 Ver análise de maturidade</a>
</div>


# Testes de Segurança {testes-seguranca:intro}

## 🧭 1. O que cobre tecnicamente {testes-seguranca:intro#1_o_que_cobre_tecnicamente}

Este capítulo define práticas de **validação e verificação da segurança aplicacional** ao longo do ciclo de vida, cobrindo:

- Testes estáticos (SAST), dinâmicos (DAST), interativos (IAST) e fuzzing
- Estratégias de cobertura mínima por risco (L1–L3)
- Integração contínua dos testes no pipeline CI/CD
- Gestão de findings e feedback ao desenvolvimento
- Rastreabilidade com os Requisitos de Segurança (Cap. 2)
- **PenTesting manual e ofensivo** como validação complementar em contextos críticos

As práticas devem ser **proporcionais à criticidade da aplicação** (ver Cap. 1) e **passíveis de verificação objetiva** com critérios de aceitação definidos.

---

## 🧪 2. Prescrição prática: o quê, quem, como, quando, porquê e para quê {testes-seguranca:intro#2_prescricao_pratica_o_que_quem_como_quando_porque_e_para_que}

### 📌 O que deve ser feito {testes-seguranca:intro#o_que_deve_ser_feito}

1. Definir a estratégia de testes por tipo de aplicação e nível de risco
2. Executar testes SAST, DAST, IAST ou fuzzing em pontos-chave do SDLC
3. Estabelecer critérios de aceitação de segurança por release
4. Avaliar findings, priorizar correções e atribuir responsabilidades
5. Garantir rastreabilidade entre requisitos e testes realizados
6. Integrar os resultados nos processos de desenvolvimento e qualidade
7. **Agendar PenTesting para aplicações críticas ou em contexto de auditoria**

---

### ⚙️ Como deve ser feito {testes-seguranca:intro#como_deve_ser_feito}

- Para **L1**: checklists manuais, scripts simples, validações informais
- Para **L2**: SAST e DAST automatizados com thresholds e gates
- Para **L3**: fuzzing, IAST, regressões automatizadas, PenTesting manual

Ferramentas típicas:
- **SAST**: Semgrep, CodeQL, SonarQube
- **DAST**: OWASP ZAP, Burp Suite
- **IAST**: Contrast, AppScan IAST
- **Fuzzing**: ZAP add-ons, RESTler, fuzzers customizados
- **PenTesting**: OWASP Testing Guide, ferramentas ofensivas manuais
- **Gestão de findings**: OWASP DefectDojo, Jira, GitHub Issues

---

### 📆 Quando aplicar {testes-seguranca:intro#quando_aplicar}

| Momento                  | Tipo de teste                   | Notas                                                            |
|--------------------------|----------------------------------|------------------------------------------------------------------|
| Pull request / commit    | SAST, linting                   | Rápido, obrigatório, com thresholds automáticos                  |
| Build diária / nightly   | DAST, testes de regressão       | Cobre findings anteriores e cenários exploratórios               |
| Pré-release              | Validação combinada + PenTest   | Fuzzing + regressão + PenTesting onde aplicável                  |
| Pós-release contínuo     | Fuzzing, monitorização dinâmica | Aplicações expostas ou com requisitos de resiliência             |

> 📌 O PenTesting deve ser executado **em todas as aplicações L3** ou quando necessário para certificação, validação independente ou resposta a findings críticos.

---

### 👥 Quem está envolvido e como {testes-seguranca:intro#quem_esta_envolvido_e_como}

| Função            | Responsabilidade                                                        |
|-------------------|-------------------------------------------------------------------------|
| Desenvolvimento   | Criar e ajustar testes, corrigir vulnerabilidades                      |
| QA / Testes       | Integrar critérios de aceitação de segurança                           |
| AppSec            | Definir estratégia, validar findings, aprovar correções                |
| DevOps            | Integrar testes no pipeline, automatizar execução                      |
| Gestão de produto | Priorizar findings, gerir impacto em roadmap                           |
| PenTester         | Executar testes manuais ofensivos, validar controlos, reportar falhas  |

---

### 🎯 Porquê / Para quê {testes-seguranca:intro#porque__para_que}

- Prevenir falhas de segurança antes de entrarem em produção
- Aumentar confiança nas releases e reduzir risco operacional
- Gerar evidência concreta de conformidade com requisitos
- Detetar regressões de segurança de forma automatizada
- **Avaliar a eficácia real dos controlos de segurança implementados**

---

## ⚠️ 3. Caveats ou limitações {testes-seguranca:intro#3_caveats_ou_limitacoes}

- Sem rastreabilidade, findings perdem contexto e impacto
- Falsos positivos são comuns sem tuning adequado
- Testes manuais não escalam se não forem seletivos
- Testes desligados dos requisitos não sustentam conformidade
- **PenTesting mal enquadrado pode gerar ruído sem impacto útil**

---

## 💡 4. Exemplos de aplicação {testes-seguranca:intro#4_exemplos_de_aplicacao}

- **Aplicação web L3**:
  - SAST contínuo com Semgrep + DAST diário com ZAP
  - Fuzzing de endpoints críticos
  - PenTesting externo por escopo ou findings acumulados
  - Gestão centralizada de findings com integração DevSecOps

- **API backend L2**:
  - SAST no CI + DAST antes de release
  - Regressão de findings com casos de teste automatizados

- **App interna L1**:
  - Checklist manual + SAST semanal
  - Correções ad-hoc com validação informal

---

## 🔍 5. O que pode ser feito mais (e porquê) {testes-seguranca:intro#5_o_que_pode_ser_feito_mais_e_porque}

- Medir a **cobertura de requisitos de segurança por release**
- Usar **BDD** para critérios de aceitação verificáveis
- Automatizar regressão de findings com casos persistentes
- Integrar rastreabilidade com ALM (Jira, GitHub)
- Criar **dashboards de maturidade** por aplicação
- Usar findings acumulados como input de escopo para **PenTesting ofensivo**

---

> 🔗 Nos addons deste capítulo encontrarás:
> - Análise de maturidade por framework (`10-maturidade.md`)
> - Aplicação no ciclo de vida (`15-aplicacao-lifecycle.md`)
> - Checklist de aplicação prática (`20-checklist-revisao.md`)
> - Rastreabilidade entre requisitos e testes (`25-rastreabilidade.md`)
> - Recomendações avançadas (`30-recomendacoes-avancadas.md`)
> - Validação ofensiva e escopo de PenTesting (`11-pentest.md`)
