---
id: aplicacao-lifecycle
title: Aplicação no Ciclo de Vida — CI/CD Seguro
description: Como aplicar as práticas de CI/CD seguro ao longo do ciclo de vida da aplicação, com rastreabilidade e stories reutilizáveis
tags: [cicd, ciclo de vida, pipelines, aplicação prática, validação]
sidebar_position: 15
---

# 📅 Aplicação no Ciclo de Vida — CI/CD Seguro {cicd-seguro:canon:aplicacao-lifecycle}

Este documento descreve **como aplicar as práticas e requisitos de segurança CI/CD** ao longo do ciclo de vida de software, desde a criação de pipelines até ao deploy e operação.  

Inclui:
- Momentos-chave de aplicação proporcional;
- Artefactos recomendados;
- Pontos de controlo auditáveis;
- **User stories representativas**, uma por prática.

> O objetivo é garantir que a segurança da cadeia CI/CD é incorporada no fluxo de trabalho técnico, com rastreabilidade e automação.

---

## ♻️ Fases de aplicação {cicd-seguro:canon:aplicacao-lifecycle#fases_de_aplicacao}

| Fase / Momento                        | Ação esperada                                                   | Práticas envolvidas              |
|--------------------------------------|------------------------------------------------------------------|----------------------------------|
| 🧱 Criação do pipeline                | Definir YAML versionado, revisão obrigatória, runners seguros    | `addon/00` a `addon/04`          |
| 🧪 Integração de testes de segurança | Ativar scanners no pipeline (SAST, secrets, IaC)                 | `addon/02`, `addon/07`           |
| 🔐 Gestão de segredos                | Injeção dinâmica via vault ou variáveis seguras                  | `addon/03`                       |
| 🧱 Deploy inicial da aplicação       | Garantir assinatura e proveniência dos artefactos                | `addon/05`, `addon/08`           |
| ⚖️ Aplicação de políticas            | Definir e aplicar gates automáticos por nível L1–L3              | `addon/06`                       |
| 🚨 Exceção a uma política CI/CD      | Registar e aprovar formalmente bypass                            | `addon/09`                       |
| 🔁 Revisão de pipeline existente     | Atualizar controlo de segredos, runners, validações              | Todos os addons                  |
| 📤 Release para produção             | Validar logs, deploy rastreável e findings resolvidos            | `addon/08`, `addon/06`, `addon/07` |

---

## 📃 Artefactos recomendados por projeto {cicd-seguro:canon:aplicacao-lifecycle#artefactos_recomendados_por_projeto}

| Tipo de artefacto                    | Obrigatório | Fase associada                     | Observações                                      |
|-------------------------------------|-------------|------------------------------------|--------------------------------------------------|
| `ci-pipeline.yml`                   | Sim         | Criação e revisão contínua         | Pipeline versionado, validado e rastreável       |
| Proveniência de artefacto (`.jsonl`) | Sim (L2/L3) | Após build                         | Proveniência SLSA + assinatura (`addon/05`)      |
| Registo de exceções CI              | Condicional | Qualquer bypass de gate ou scanner | Inclui motivo, aprovação e prazo (`addon/09`)    |
| Scorecard / métricas de conformidade| Recomendado | Mensal                             | Integração com reporting organizacional          |
| Log de execuções e deploys          | Sim         | Release e operação                 | Requer rastreio ponta-a-ponta (`addon/08`)       |

---

## 🔄 Integração com ciclo de vida real {cicd-seguro:canon:aplicacao-lifecycle#integracao_com_ciclo_de_vida_real}

As práticas devem estar ligadas a:

- Pull requests (ex: alteração a pipelines, permissões, workflows)
- Releases e deploys (ex: validação de proveniência antes de promoção)
- Auditorias de conformidade (ex: revisão de exceções ou métricas)
- Eventos técnicos automatizáveis (ex: revalidação após mudança em runners, segredos ou repositório)

---

## 🧪 Pontos de controlo auditáveis {cicd-seguro:canon:aplicacao-lifecycle#pontos_de_controlo_auditaveis}

- Proteção e revisão de pipelines (`addon/01`)
- Validações de segurança ativas no pipeline (`addon/07`)
- Existência de política por nível de risco (`addon/06`)
- Proveniência e assinatura de artefactos (`addon/05`)
- Registo de exceções CI/CD com aprovação (`addon/09`)
- Rastreabilidade de build → deploy (`addon/08`)

---

## 🧾 User Stories por prática prescrita {cicd-seguro:canon:aplicacao-lifecycle#user_stories_por_pratica_prescrita}

### 00. Gestão segura de código fonte {cicd-seguro:canon:aplicacao-lifecycle#00_gestao_segura_de_codigo_fonte}

> **Como responsável técnico**,  
> Quero que todos os repositórios de aplicações tenham branches protegidas, revisão obrigatória e proibição de `force push`,  
> Para garantir que apenas código revisto e rastreável entra em produção.

---

### 01. Design seguro dos pipelines {cicd-seguro:canon:aplicacao-lifecycle#01_design_seguro_dos_pipelines}

> **Como engenheiro de DevOps**,  
> Quero garantir que todos os pipelines são versionados, revisados via pull request e com triggers explicitamente controlados,  
> Para impedir alterações silenciosas ou execuções não autorizadas.

---

### 02. Segurança do código dentro do pipeline {cicd-seguro:canon:aplicacao-lifecycle#02_seguranca_do_codigo_dentro_do_pipeline}

> **Como developer**,  
> Quero que o pipeline da minha aplicação execute automaticamente validações de segurança como SAST, secrets scanning e análise de IaC,  
> Para detetar vulnerabilidades cedo e evitar que código inseguro seja integrado.

---

### 03. Gestão e injeção segura de segredos {cicd-seguro:canon:aplicacao-lifecycle#03_gestao_e_injecao_segura_de_segredos}

> **Como engenheiro de plataforma**,  
> Quero que todos os segredos usados em pipelines sejam injetados dinamicamente com escopo mínimo e nunca apareçam em logs,  
> Para reduzir o risco de exposição acidental ou uso indevido.

---

### 04. Isolamento e proteção de runners {cicd-seguro:canon:aplicacao-lifecycle#04_isolamento_e_protecao_de_runners}

> **Como administrador de infraestrutura CI/CD**,  
> Quero que todos os runners utilizados em pipelines críticos sejam descartáveis, não privilegiados e segregados por tipo de aplicação,  
> Para impedir persistência de malware ou fuga lateral de informação.

---

### 05. Integridade e proveniência de artefactos {cicd-seguro:canon:aplicacao-lifecycle#05_integridade_e_proveniencia_de_artefactos}

> **Como DevOps**,  
> Quero garantir que todos os artefactos gerados nos pipelines são assinados e acompanhados de proveniência verificável,  
> Para que apenas builds legítimos possam ser promovidos ou deployados.

---

### 06. Políticas e gates por nível de aplicação {cicd-seguro:canon:aplicacao-lifecycle#06_politicas_e_gates_por_nivel_de_aplicacao}

> **Como revisor de segurança**,  
> Quero que o pipeline aplique políticas de validação e gates de segurança distintos por nível de risco (L1–L3),  
> Para assegurar que aplicações críticas não progridem sem validações adequadas.

---

### 07. Validações de segurança integradas no pipeline {cicd-seguro:canon:aplicacao-lifecycle#07_validacoes_de_seguranca_integradas_no_pipeline}

> **Como responsável de AppSec**,  
> Quero que todos os pipelines contenham scanners automatizados de segurança (SAST, secrets, IaC, containers, SBOM),  
> Para garantir cobertura contínua e proporcional às exigências do Capítulo 02.

---

### 08. Rastreabilidade de execuções, assinaturas e deploys {cicd-seguro:canon:aplicacao-lifecycle#08_rastreabilidade_de_execucoes_assinaturas_e_deploys}

> **Como auditor interno**,  
> Quero conseguir identificar, para cada deploy, qual o commit, pipeline e responsável associado,  
> Para garantir rastreabilidade completa e facilitar investigações ou validações de conformidade.

---

### 09. Controlo de exceções e visibilidade organizacional {cicd-seguro:canon:aplicacao-lifecycle#09_controlo_de_excecoes_e_visibilidade_organizacional}

> **Como responsável de GRC**,  
> Quero que todas as exceções a políticas CI/CD sejam registadas, aprovadas e monitorizadas,  
> Para evitar bypass informal de controlos e garantir visibilidade de maturidade.

