---
id: aplicacao-lifecycle
title: Aplicação de Monitorização no Ciclo de Vida
sidebar_position: 15
description: Aplicação prática das práticas de monitorização, alerta e resposta ao longo do ciclo de vida de software.
tags: [tipo:anexo, grupo:execucao, tema:monitorizacao, deteccao, resposta, kpi]
---


# 🧭 Aplicação das Práticas de Monitorização ao Longo do Ciclo de Vida {monitorizacao-operacoes:canon:aplicacao-lifecycle}

Este documento descreve **como aplicar as práticas de logging, alertas, correlação e resposta descritas neste capítulo ao longo do ciclo de vida do desenvolvimento** — desde a conceção da aplicação até à sua operação.

O foco é garantir **visibilidade contínua**, **deteção eficaz de incidentes** e **resposta coordenada**, com base em critérios proporcionais ao risco (L1, L2, L3).

---

## 🗓️ Quando aplicar {monitorizacao-operacoes:canon:aplicacao-lifecycle#quando_aplicar}

| Fase do Ciclo de Vida     | Prática aplicada                                             | Artefacto ou Evidência                 |
|---------------------------|--------------------------------------------------------------|----------------------------------------|
| Concepção / Design        | Definir eventos, domínios de monitorização, owners          | Documento de arquitetura               |
| Implementação             | Logging estruturado, tagging, testes de cobertura           | Código com eventos + pull request      |
| Testes                    | Simulação de eventos e validação de alertas                 | Logs de teste, triggers no SIEM        |
| Integração CI/CD          | Configuração de forwarders, retenção, regras de alerta      | Configs de logging + regras no SIEM    |
| Validação / Release       | Verificação de cobertura, correlação entre fontes           | Auditoria de logs e correlação         |
| Operação / Produção       | Monitorização de MTTD, MTTR, tuning de alertas, resposta IR | Dashboards, tickets, indicadores       |

---

## 👥 Quem executa cada ação {monitorizacao-operacoes:canon:aplicacao-lifecycle#quem_executa_cada_acao}

| Perfil / Função      | Responsabilidades principais                                          |
|----------------------|----------------------------------------------------------------------|
| Desenvolvimento      | Implementação de eventos, formato estruturado, integração com CI/CD  |
| AppSec / Segurança   | Definição de eventos críticos, alertas, tuning e métricas            |
| DevOps / SRE         | Transporte de logs, integração com SIEM, retenção                    |
| QA / Validação       | Testes de cobertura e triggers                                       |
| Produto / GRC        | Aprovação de exceções, visibilidade de indicadores e riscos          |
| Resposta a Incidentes| Integração com IRP, execução de playbooks, análise de incidentes     |

---

## 📘 User Stories Reutilizáveis {monitorizacao-operacoes:canon:aplicacao-lifecycle#user_stories_reutilizaveis}

### 🟦 Avaliar requisitos de monitorização por nível de risco {monitorizacao-operacoes:canon:aplicacao-lifecycle#avaliar_requisitos_de_monitorizacao_por_nivel_de_risco}

> Como engenheiro de segurança, quero identificar os requisitos mínimos de monitorização com base na classificação L1–L3, para garantir proporcionalidade e cobertura adequada.

**Checklist:**
- [ ] Risco classificado (Cap. 01)
- [ ] Matriz de controlo aplicada (addon/08)
- [ ] Requisitos mínimos definidos por Lx

---

### 🟦 Definir domínios e eventos críticos {monitorizacao-operacoes:canon:aplicacao-lifecycle#definir_dominios_e_eventos_criticos}

> Como arquiteto, quero definir quais domínios da aplicação e eventos devem ser monitorizados, para garantir visibilidade dos fluxos mais críticos.

**Checklist:**
- [ ] Domínios definidos (ex: login, erro, infraestrutura)
- [ ] Eventos críticos selecionados
- [ ] Owner e origem definidos

---

### 🟦 Implementar logging estruturado {monitorizacao-operacoes:canon:aplicacao-lifecycle#implementar_logging_estruturado}

> Como developer, quero que os eventos definidos sejam registados em formato estruturado e enviados para o sistema centralizado.

**Checklist:**
- [ ] JSON / ECS com campos obrigatórios
- [ ] Logs contêm `user.id`, `trace.id`
- [ ] Forwarders configurados

---

### 🟦 Configurar alertas automáticos {monitorizacao-operacoes:canon:aplicacao-lifecycle#configurar_alertas_automaticos}

> Como engenheiro de segurança, quero configurar regras de alerta para eventos relevantes, com base na sua severidade e frequência.

**Checklist:**
- [ ] Eventos com triggers definidos
- [ ] Severidade atribuída
- [ ] Alertas testados em ambiente de staging

---

### 🟦 Validar funcionamento dos alertas {monitorizacao-operacoes:canon:aplicacao-lifecycle#validar_funcionamento_dos_alertas}

> Como QA, quero simular eventos críticos e verificar se os alertas são corretamente acionados e encaminhados.

**Checklist:**
- [ ] Simulação de evento em ambiente seguro
- [ ] Alerta visível no SIEM / ferramenta
- [ ] Resultado documentado

---

### 🟦 Correlacionar eventos entre fontes {monitorizacao-operacoes:canon:aplicacao-lifecycle#correlacionar_eventos_entre_fontes}

> Como analista, quero conseguir seguir o percurso de um evento entre diferentes sistemas, para compreender impacto e origem.

**Checklist:**
- [ ] Eventos incluem IDs cruzados
- [ ] Logs de aplicação, infra e pipeline integrados
- [ ] Consulta entre fontes validada

---

### 🟦 Integrar com sistema de resposta (IRP) {monitorizacao-operacoes:canon:aplicacao-lifecycle#integrar_com_sistema_de_resposta_irp}

> Como engenheiro de resposta, quero que certos alertas acionem automaticamente tickets ou workflows de resposta.

**Checklist:**
- [ ] Integração com IRP / SOAR
- [ ] Playbooks automatizados definidos
- [ ] Triage e acionamento automático em curso

---

### 🟦 Monitorizar eficácia e ajustar alertas {monitorizacao-operacoes:canon:aplicacao-lifecycle#monitorizar_eficacia_e_ajustar_alertas}

> Como gestor de segurança, quero acompanhar a evolução dos tempos de deteção e resposta (MTTD / MTTR), e ajustar alertas com base em falsos positivos.

**Checklist:**
- [ ] MTTD e MTTR medidos
- [ ] Alertas ajustados com base em incidentes reais
- [ ] Indicadores reportados a GRC / CISO

---

## 🧾 Artefactos Esperados {monitorizacao-operacoes:canon:aplicacao-lifecycle#artefactos_esperados}

| Artefacto                          | Formato Esperado         | Local / Referência técnica         |
|------------------------------------|---------------------------|------------------------------------|
| Plano de eventos e monitorização   | Markdown / tabela         | `docs/monitorizacao/`             |
| Regras de alerta                   | YAML / JSON               | `security/siem/alertas/`          |
| Configuração de forwarders         | `.conf`, `.yaml`          | `infra/logging/forwarders/`       |
| Dashboard de métricas              | Grafana / Kibana export   | `dashboards/security/`            |
| Integração com IRP / tickets       | JSON / API                | `integracoes/IRP/`                |

---

## ⚖️ Aplicação proporcional por nível de risco (L1–L3) {monitorizacao-operacoes:canon:aplicacao-lifecycle#aplicacao_proporcional_por_nivel_de_risco_l1l3}

| Prática                            | L1 (baixo risco)         | L2 (moderado)               | L3 (elevado)                     |
|------------------------------------|---------------------------|------------------------------|----------------------------------|
| Logging                            | Local, não estruturado    | Estruturado, com envio       | Estruturado + tagging + retenção |
| Alertas                            | Manuais ou inexistentes   | Regras simples               | Alertas correlacionados e críticos |
| Correlação                         | Não aplicável             | Por sessão e origem          | Multi-fonte, com deduplicação     |
| Retenção de logs                   | Não exigida               | ≥ 14 dias, ACL básica         | ≥ 30 dias, TLS + controle de acesso |
| Resposta a incidentes              | Manual, sem owner         | Canal Slack / e-mail         | Integração IRP + triage automático |
| Métricas (MTTD / MTTR)             | Não medidas               | Análise semestral            | Dashboards contínuos              |
| Simulações e testes                | Não requeridos            | Testes QA antes de go-live   | Simulação + replay mensal         |

> 🔍 A aplicação proporcional assegura que o esforço operacional é ajustado ao risco real da aplicação, maximizando o impacto com os recursos disponíveis.

---

## 🧭 Recomendações finais para equipas de projeto {monitorizacao-operacoes:canon:aplicacao-lifecycle#recomendacoes_finais_para_equipas_de_projeto}

- Incluir requisitos de monitorização na **Definition of Done**;
- Validar alertas e cobertura de eventos como parte da fase de QA;
- Monitorizar a eficácia dos alertas ao longo da operação;
- Integrar os indicadores de MTTD/MTTR no ciclo de melhoria contínua;
- Reutilizar os modelos e artefactos como parte de um **padrão de projeto transversal**.

> 📌 A integração destas práticas permite visibilidade e controlo em runtime, sendo essencial para ambientes regulados, críticos ou de alta exposição.
