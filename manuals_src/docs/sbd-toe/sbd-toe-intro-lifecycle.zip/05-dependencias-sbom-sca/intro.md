---
id: intro
title: Dependências, SBOM e SCA
description: Práticas para gestão segura de bibliotecas externas, SBOM e análise contínua de vulnerabilidades
tags: [sca, sbom, terceiros, dependencias, supply-chain, rastreabilidade]

---
import Badge from '@site/src/components/Badge';

<div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1rem' }}>
  <Badge color="warning">Capítulo Basilar</Badge>
  <Badge color="info">SAMM: 2 / 3</Badge>
  <Badge color="info">BSIMM: CMVM1.1, SR1.2, SE2.4</Badge>
  <Badge color="info">SSDF: PS.3.2, RV.1.1, RV.1.3</Badge>
  <Badge color="info">SLSA: Nível 2 / 4</Badge>
  <Badge color="info">DSOMM: 2 / 3 (média)</Badge>
  <a href="./canon/10-maturidade.md" style={{ marginLeft: 'auto', fontSize: '0.9rem' }}>📄 Ver análise de maturidade</a>
</div>


# Dependências, SBOM e Análise de Terceiros {dependencias-sbom-sca:intro}

## 🧭 1. O que cobre tecnicamente {dependencias-sbom-sca:intro#1_o_que_cobre_tecnicamente}

Este capítulo define as práticas essenciais para **inventariar, validar e controlar dependências externas**, incluindo bibliotecas open-source, SDKs, binários de terceiros e imagens base. Cobre:

- Geração e atualização sistemática de **SBOMs (Software Bill of Materials)**
- Utilização de ferramentas de **SCA (Software Composition Analysis)**, incluindo análise **transitiva**
- **Governaça de bibliotecas** e critérios formais de aceitação
- Definição de **políticas de atualização, TTL, locking e patching**
- **Controlo de proveniência e validação da origem de pacotes e registos**
- Integração de SBOM/SCA em pipelines de CI/CD, com bloqueio automatizado
- Gestão de **exceções formalizadas** para CVEs não corrigidos
- **Rastreabilidade de vulnerabilidades** desde o SBOM até à release

---

## 🧪 2. Prescrição prática: o quê, quem, como, quando, porquê e para quê {dependencias-sbom-sca:intro#2_prescricao_pratica_o_que_quem_como_quando_porque_e_para_que}

### 📌 O que deve ser feito {dependencias-sbom-sca:intro#o_que_deve_ser_feito}

1. Gerar e manter um **SBOM versionado por build** e artefacto.
2. Executar scanners de **SCA**, incluindo análise transitiva, com base no SBOM gerado.
3. Aplicar políticas formais para:
   - Aprovação de bibliotecas e validação da sua proveniência
   - Atualização periódica com TTL e gestão de versões
   - Uso de **lockfiles obrigatórios** para garantir builds reprodutíveis
   - Justificação e expiração de exceções a vulnerabilidades
4. Usar repositórios internos ou proxies com fallback controlado e auditado.
5. Integrar tudo no pipeline de CI/CD, com bloqueio automatizado e reporting.
6. Garantir rastreabilidade entre findings, artefactos, decisões e correções.

### ⚙️ Como deve ser feito {dependencias-sbom-sca:intro#como_deve_ser_feito}

- SBOMs em **CycloneDX** ou **SPDX**, gerados com `syft`, `cyclonedx-maven-plugin`, `trivy`, etc.
- Scanners SCA como `grype`, `Trivy`, `OWASP Dependency-Check`, ou ferramentas comerciais integradas.
- Findings documentados com ligação a tarefas (ex: Jira, GitHub issues), artefactos e versões.
- Repositórios privados (ex: Verdaccio, Artifactory, Nexus) com controlo de acesso, whitelisting e fallback auditado.
- Templates formais para exceções (`excecoes.yaml`) com validade, controlo compensatório e revalidação.

### 📆 Quando aplicar {dependencias-sbom-sca:intro#quando_aplicar}

| Momento                          | Ação esperada                                    |
|----------------------------------|--------------------------------------------------|
| 📦 Adição de nova dependência     | Revisão de origem, licença, manutenção e CVEs    |
| 🧱 Build de produção             | Geração de SBOM + análise SCA + bloqueio por criticidade |
| 🚀 Release                       | Validação de findings pendentes e aceitação formal |
| 🔁 Sprint / ciclo regular        | Atualização automática de bibliotecas com revisão |
| 🚨 CVE público relevante         | Verificação de impacto e ação sobre releases afetadas |

### 👥 Quem está envolvido e como {dependencias-sbom-sca:intro#quem_esta_envolvido_e_como}

| Papel/Função     | Responsabilidades-chave                                                    |
|------------------|-----------------------------------------------------------------------------|
| Dev / Dev Lead   | Inclusão e justificação de dependências, triagem de findings               |
| AppSec / Segurança | Definição de políticas, aceitação de exceções, revisão de risco residual |
| CI/CD / DevOps   | Integração de scanners, geração de artefactos, controlo de registos        |
| Produto / Gestão | Avaliação de risco e decisão de go/no-go em caso de findings não resolvidos |

> ✅ Todas as exceções a vulnerabilidades devem ser **aprovadas formalmente**, rastreadas e reavaliadas.

### 🎯 Porquê / Para quê {dependencias-sbom-sca:intro#porque__para_que}

- Reduzir a superfície de ataque associada a componentes externos.
- Prevenir a utilização de bibliotecas abandonadas, vulneráveis ou maliciosas.
- Acelerar a resposta a alertas de CVEs com impacto real.
- Garantir conformidade com exigências de auditoria e regulatórias (NIS2, SSDF, CRA).
- Tornar **auditável e justificada** a aceitação de risco residual.

---

## ⚠️ 3. Caveats ou limitações da prescrição {dependencias-sbom-sca:intro#3_caveats_ou_limitacoes_da_prescricao}

- SCA não cobre código próprio nem análise dinâmica — requer ser combinado com outras práticas.
- SBOMs só têm valor se forem **completos, atualizados e ligados a artefactos reais**.
- Falsos positivos ou CVEs com impacto nulo **devem ser tratados formalmente, não ignorados**.
- Confiar cegamente em registos públicos **é uma falha crítica — devem existir proxies internos, com validação de origem**.

---

## 💡 4. Exemplos de aplicação {dependencias-sbom-sca:intro#4_exemplos_de_aplicacao}

Para um microserviço backend (L2) escrito em Node.js:

- O pipeline inclui:
  - `syft` para gerar SBOM CycloneDX
  - `grype` para escanear vulnerabilidades (incluindo dependências transitivas)
  - Validador de exceções (`excecoes.yaml`) antes do deploy
- As bibliotecas são geridas com `Verdaccio`, com fallback restrito ao `npmjs.org`.
- Findings críticos resultam em:
  - Tarefa automática no Jira
  - Triagem com base em CVSS + impacto funcional
  - Correção ou aceitação justificada com data de validade

---

## 🧩 Ligações a outros capítulos {dependencias-sbom-sca:intro#ligacoes_a_outros_capitulos}

| Capítulo                        | Relação técnica e de processo                                                    |
|---------------------------------|----------------------------------------------------------------------------------|
| `02-requisitos-seguranca`       | Define os requisitos mínimos aplicáveis a bibliotecas externas                   |
| `06-desenvolvimento-seguro`     | Aplica as restrições de bibliotecas e dependências no código                     |
| `07-cicd-seguro`                | Garante que SBOM e SCA sejam integrados e executados de forma segura             |
| `08-iac-infraestrutura`         | Usa componentes reutilizáveis que também devem ser inventariados e validados     |
| `09-containers-imagens`         | Gera SBOMs de imagens, valida dependências em camadas base                       |
| `10-testes-seguranca`           | Valida exceções a CVEs com impacto real em runtime                               |
| `11-deploy-seguro`              | Verifica findings pendentes e aplica políticas de go/no-go na entrega            |
| `12-monitorizacao-operacoes`    | Acompanha alertas e tracking de vulnerabilidades após a entrega                  |

---

> 🧱 Este capítulo é **obrigatório para projetos com risco L2 e L3**, e altamente recomendado em qualquer sistema com dependências externas.  
> Ignorar a gestão formal de bibliotecas e pacotes externos **é um risco direto de comprometimento da cadeia de fornecimento**.
