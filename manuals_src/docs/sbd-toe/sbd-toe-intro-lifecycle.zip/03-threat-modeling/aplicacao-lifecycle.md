---
id: aplicacao-lifecycle
title: Aplicação de Threat Modeling no Ciclo de Vida
tags: [tipo:anexo, grupo:execucao, tema:threat-modeling]
---

# 🔄 Aplicação de Threat Modeling no Ciclo de Vida {threat-modeling:canon:aplicacao-lifecycle}

Este anexo define como aplicar de forma sistemática as práticas de Threat Modeling ao longo do ciclo de vida do software.  
Inclui templates de user stories, tarefas técnicas e momentos recomendados para execução proporcional ao risco da aplicação (L1–L3).

---

## 🧭 Quando aplicar Threat Modeling {threat-modeling:canon:aplicacao-lifecycle#quando_aplicar_threat_modeling}

| Tipo de processo | Momento recomendado                         | Quem participa                 | Notas                                                       |
|------------------|---------------------------------------------|--------------------------------|--------------------------------------------------------------|
| Agile / Scrum    | Início do épico ou funcionalidade crítica   | PO, Arquiteto, Segurança        | Threat modeling leve ou completo, conforme risco             |
| Waterfall        | Fase de design ou arquitetura               | Arquiteto, QA, AppSec           | Requisitos de segurança e controlo das ameaças documentados  |
| CI/CD Contínuo   | Trigger por alteração técnica ou integração | Dev, Segurança, AppSec          | Scripts e modelos pré-validados podem ser reutilizados       |

---

## 🧾 User Stories e Cartões Reutilizáveis {threat-modeling:canon:aplicacao-lifecycle#user_stories_e_cartoes_reutilizaveis}

### 🟦 Story: Criação de modelo de ameaça {threat-modeling:canon:aplicacao-lifecycle#story_criacao_de_modelo_de_ameaca}

> Como equipa técnica, queremos criar um modelo de ameaça da nova funcionalidade, para antecipar riscos e definir controlos apropriados.

**Checklist:**
- [ ] DFD criado com trust boundaries
- [ ] Ameaças STRIDE ou LINDDUN identificadas
- [ ] Categorias de risco atribuídas por criticidade
- [ ] Requisitos derivados atribuídos (Cap. 2)

---

### 🟦 Story: Validação de arquitetura com threat modeling {threat-modeling:canon:aplicacao-lifecycle#story_validacao_de_arquitetura_com_threat_modeling}

> Como arquiteto, quero incluir o modelo de ameaça no processo de validação de arquitetura, para garantir que riscos estão identificados antes do desenvolvimento.

**Checklist:**
- [ ] DFD incluído na ficha de solução
- [ ] Lista de ameaças documentada e validada
- [ ] Controlo ou exceção associado a cada ameaça
- [ ] AppSec envolvido na revisão

---

### 🟦 Story: Atualização do modelo após alteração técnica {threat-modeling:canon:aplicacao-lifecycle#story_atualizacao_do_modelo_apos_alteracao_tecnica}

> Como developer, quero atualizar o modelo de ameaça sempre que há mudanças significativas, para manter a rastreabilidade e garantir que os novos riscos são tratados.

**Checklist:**
- [ ] Alteração técnica documentada
- [ ] Ameaças reavaliadas ou reclassificadas
- [ ] Requisitos alterados ou novos criados
- [ ] Versão do modelo atualizada

---

### 🟦 Story: Justificação formal de risco aceite {threat-modeling:canon:aplicacao-lifecycle#story_justificacao_formal_de_risco_aceite}

> Como responsável de segurança, quero documentar exceções com risco aceite, para garantir que há rastreabilidade e reavaliação periódica.

**Checklist:**
- [ ] Ameaça mapeada
- [ ] Justificação técnica completa
- [ ] Validade definida (data, sprint, release)
- [ ] Reavaliação agendada

---

### 🟦 Story: Integração com CI/CD {threat-modeling:canon:aplicacao-lifecycle#story_integracao_com_cicd}

> Como engenheiro de CI/CD, quero validar automaticamente a existência e atualidade do modelo de ameaça antes de cada release.

**Checklist:**
- [ ] Presença dos ficheiros mínimos (`dfd`, `threats.yaml`, `mitigations.md`)
- [ ] Última revisão < 30 dias ou exceção válida
- [ ] Ligação a requisitos do Cap. 2 rastreável
- [ ] Build falha se ameaças críticas não forem tratadas

---

### 🟦 Story: Substituição do modelo manual por IriusRisk {threat-modeling:canon:aplicacao-lifecycle#story_substituicao_do_modelo_manual_por_iriusrisk}

> Como responsável técnico, quero integrar o threat modeling com o IriusRisk, para automatizar o mapeamento entre ameaças e requisitos.

**Checklist:**
- [ ] Projeto configurado e sincronizado com repositório
- [ ] Ameaças e requisitos exportados em JSON/CSV
- [ ] Decisões documentadas e justificadas
- [ ] Validação automática incluída no CI/CD

---

## 📁 Artefactos esperados por projeto {threat-modeling:canon:aplicacao-lifecycle#artefactos_esperados_por_projeto}

| Artefacto                      | Formato recomendando     | Onde guardar / integrar               |
|-------------------------------|---------------------------|---------------------------------------|
| DFD com trust boundaries       | Draw.io / Mermaid         | Diretório `docs/` ou `threat-model/`  |
| Lista de ameaças               | `threats.yaml`            | Diretório `threat-model/`             |
| Mitigações                     | `mitigations.md` ou CSV   | Diretório `threat-model/`             |
| Justificações de risco aceite  | `decisions.md` ou IriusRisk | Diretório `threat-model/` ou export  |
| Requisitos derivados           | YAML/CSV/JSON             | Ligação com Catálogo Cap. 2           |
| Log de revisão                 | `threat-model.yml`        | CI/CD + auditoria                     |

---

## ⚖️ Aplicação proporcional por nível de risco (L1–L2–L3) {threat-modeling:canon:aplicacao-lifecycle#aplicacao_proporcional_por_nivel_de_risco_l1l2l3}

| Prática                         | L1 (baixo risco)                | L2 (risco moderado)           | L3 (risco elevado)                                |
|--------------------------------|----------------------------------|-------------------------------|---------------------------------------------------|
| Modelo de ameaça (DFD + STRIDE)| Opcional simplificado            | Obrigatório                   | Detalhado + com validação AppSec                  |
| Frequência de revisão          | Apenas alterações significativas | Cada release ou sprint        | Em cada merge importante                          |
| Formalização de exceções       | Comentário informal              | Issue ou task documentada     | Justificação formal com owner e validade          |
| Integração com CI/CD           | Não exigida                      | Validação opcional            | Validação obrigatória e bloqueio por falha crítica |
| Ligação a requisitos Cap. 2    | Não rastreada                    | Rastreável por referência     | Obrigatória e auditável                           |

---

## ✅ Recomendações finais {threat-modeling:canon:aplicacao-lifecycle#recomendacoes_finais}

- Aplicar o threat modeling desde os primeiros momentos de design ou planeamento;
- Tratar o modelo como artefacto contínuo e versionado, não como entregável único;
- Automatizar o máximo possível: validação, ligação a backlog, CI/CD;
- Formar facilitadores internos com skills de modelação, segurança e arquitetura;
- Reutilizar modelos existentes sempre que possível, mas revalidar em cada contexto.

> 🔁 O Threat Modeling é um artefacto transversal de segurança — permite justificar requisitos, mitigar riscos reais e auditar decisões. Deve estar sempre visível e validado.
